package com;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.filechooser.*;
import java.text.*;
import java.util.*;
import javax.swing.Timer; 

//�������ͽ���
class Mcdonald extends JFrame{
	//��ʼ�����
	private JTextField txtName,txtTel,txtEmail,txtMoney,txtFoodName;
	private JTextArea tatAddress;
	private JLabel lblName,lblAddress,lblTel,lblEmail,lblMoney,lblDate,lblTime,lblFoodPicture,lblTitlePicture,lblMsgbox,lblMessage;
	private JRadioButton rdbPizza,rdbBurger;
	private ButtonGroup bg;
	private JComboBox cmbDate;
	private JCheckBox []cebFood;
	private JButton btnOK,btnExit,btnMsgbox,btnRefurbish,btnESC,btnChangeBackColor,btnChangeForeColor;
	private	JPanel []pnlName;
	private	JPanel barPanel,picPanel;
	private JPanel pnlMsgbox1,pnlMsgbox2;
	private Container m;	//��������
	private ImageIcon []icoName;
	private JMenu mnuSystem,mnuSetting,mnuBackColor,mnuForeColor,mnuPicture,mnuFoodName;
	private JMenuBar mnbBase;
	private JMenuItem []mniName;
	private JToolBar bar;
	private Color colBackColor,colMsgboxBackColor,colForeColor,colMsgboxForeColor;;
	private JFileChooser chooser;
	private JOptionPane InputPanel;
	private String []strFood;
	private String []strNewFood;
	private int i,intTime=0,a,b,c,p,h;
	private Timer colorTimer,pictureTimer;
	//���캯��
	public Mcdonald (String title){
		super(title);
		a=0;
		b=0;
		c=0;
		p=0;
		h=0;
		m=getContentPane();	//�������
		
		//�����ļ��Ի���
		chooser=new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		InputPanel=new JOptionPane();
		//��ʼ������
		Font f=new Font("����",Font.BOLD,36);
		//��ʼ������ɫ��������ɫ
		colBackColor=new Color(255,255,255);
		colMsgboxBackColor=new Color(255,255,255);
		colForeColor=new Color(0,0,0);
		colMsgboxForeColor=new Color(0,0,0);
		cebFood=new JCheckBox[8];
		for(i=0;i<8;i++){
			cebFood[i]=new JCheckBox();
		}
		//��ʼ�����
		pnlName=new JPanel[14];
		for(i=0;i<14;i++){
			pnlName[i]=new JPanel();
		}
		pnlMsgbox1=new JPanel();
		pnlMsgbox2=new JPanel();
		//��ʼ��ʳ������
		strFood=new String[8];
		strNewFood =new String[8];
		strFood[0]=new String("��ײ�");
		strFood[1]=new String("�ܲ�");
		strFood[2]=new String("����");
		strFood[3]=new String("�Ϲ�");
		strFood[4]=new String("ƻ��");
		strFood[5]=new String("�㽶");
		strFood[6]=new String("����");
		strFood[7]=new String("����");
		for(i=0;i<8;i++){
			strNewFood[i]=strFood[i]; 
		}
		//��ʼ����ǩ
		lblName=new JLabel("�ͻ�����:");
		lblAddress=new JLabel("�ͻ���ַ:");
		lblTel=new JLabel("�ͻ��绰:");
		lblEmail=new JLabel("��������:");
		lblMoney=new JLabel("�۸�");
		lblDate=new JLabel("�ʹ�����");
		lblTime=new JLabel("��ӭ�������Ͷ���ϵͳ");
		lblFoodPicture=new JLabel();
		lblTitlePicture=new JLabel();
		lblMsgbox=new JLabel();
		lblMessage=new JLabel();
		//��ʼ���ı���
		txtName=new JTextField(18);
		tatAddress=new JTextArea(3,18);
		tatAddress.setLineWrap(true);
		JScrollPane scoPane=new JScrollPane(tatAddress);
		txtTel=new JTextField(18);
		txtEmail=new JTextField(18);
		txtMoney=new JTextField("$0",6);
		txtFoodName=new JTextField();

		//���ü۸��ı�������д
		txtMoney.setEditable(false);
		
		//���õ�ѡ��ť��
		rdbPizza=new JRadioButton("Pizza");
		rdbBurger=new JRadioButton("Burger");
		bg=new ButtonGroup();
		rdbPizza.setSelected(true);
		bg.add(rdbPizza);
		bg.add(rdbBurger);
		
		//��������������
		String Dates[]={"Today","Tomorrow","The Day After Tomorrow" 
		};
		cmbDate=new JComboBox(Dates);
		//���õ�͵����ิѡ��
		for(i=0;i<8;i++){
			cebFood[i]=new JCheckBox(strFood[i]);
		}
		
		//����ͼƬ
		icoName=new ImageIcon[16];
		icoName[0]=new ImageIcon("Image/jtb.jpg");
		icoName[1]=new ImageIcon("Image/jwb.jpg");
		icoName[2]=new ImageIcon("Image/kfc.jpg");
		icoName[3]=new ImageIcon("Image/kl.jpg");
		icoName[4]=new ImageIcon("Image/mdl.jpg");
		icoName[5]=new ImageIcon("Image/ptb.jpg");
		icoName[6]=new ImageIcon("Image/sd.jpg");
		icoName[7]=new ImageIcon("Image/st.jpg");
		icoName[8]=new ImageIcon("Image/McDonald.jpg");
		icoName[9]=new ImageIcon("Image/Refurbish.gif");
		icoName[10]=new ImageIcon("Image/BackColor.gif");
		icoName[11]=new ImageIcon("Image/ForeColor.gif");
		icoName[12]=new ImageIcon("Image/ESC.gif");
		icoName[13]=new ImageIcon("Image/Error.gif");
		icoName[14]=new ImageIcon("Image/Error2.gif");
		icoName[15]=new ImageIcon("Image/Right.gif");

		//���ð�ť����
		btnOK=new JButton("Order");
		btnExit=new JButton("Exit");
		btnMsgbox=new JButton("OK");
		//���ù�����������
		btnRefurbish=new JButton(icoName[9]);
		btnRefurbish.setToolTipText("ˢ��");
		btnChangeBackColor=new JButton(icoName[10]);
		btnChangeBackColor.setToolTipText("�޸ı���ɫ");
		btnChangeForeColor=new JButton(icoName[11]);
		btnChangeForeColor.setToolTipText("�޸�������ɫ");
		btnESC=new JButton(icoName[12]);
		btnESC.setToolTipText("�˳�");
		bar=new JToolBar();
		bar.add(btnRefurbish);
		bar.addSeparator();
		bar.add(btnChangeBackColor);
		bar.addSeparator();
		bar.add(btnChangeForeColor);
		bar.addSeparator();
		bar.add(btnESC);
		bar.addSeparator();
		bar.add(lblMessage);
		
		//���Ӳ˵�����
		mnbBase=new JMenuBar();
		mnuSystem=new JMenu("ϵͳ");
		mnuSetting=new JMenu("����");
		mnuBackColor=new JMenu("����ɫ");
		mnuForeColor=new JMenu("������ɫ");
		mnuPicture=new JMenu("�޸�ͼƬ");
		mnuFoodName=new JMenu("�޸�ʳ������");
		mniName=new JMenuItem[23];
		mniName[0]=new JMenuItem("ˢ��");
		mniName[1]=new JMenuItem("�˳�");
		mniName[2]=new JMenuItem("������");
		mniName[3]=new JMenuItem("�Ի���");
		mniName[4]=new JMenuItem("������");
		mniName[5]=new JMenuItem("�Ի���");
		mniName[6]=new JMenuItem("������ͼƬ");
		for(i=7;i<15;i++){
			mniName[i]=new JMenuItem(strFood[i-7]);
		}
		for(i=15;i<23;i++){
			mniName[i]=new JMenuItem(strNewFood[i-15]);
		}
		mniName[0].addActionListener(new Refurbish());
		mniName[1].addActionListener(new ESC());
		//���˵������¼�
		for(i=2;i<6;i++){
			mniName[i].addActionListener(new ColorChoose());
		}
		for(i=6;i<15;i++){
			mniName[i].addActionListener(new PictureChoose());
		}
		for(i=15;i<23;i++){
			mniName[i].addActionListener(new FoodChoose());
		}
		//���Ӳ˵���
		mnuSystem.add(mniName[0]);
		mnuSystem.addSeparator();
		mnuSystem.add(mniName[1]);
		mnuSetting.add(mnuBackColor);
		mnuSetting.addSeparator();
		mnuSetting.add(mnuForeColor);
		mnuSetting.addSeparator();
		mnuSetting.add(mnuPicture);
		mnuSetting.addSeparator();
		mnuSetting.add(mnuFoodName);
		mnuBackColor.add(mniName[2]);
		mnuBackColor.addSeparator();
		mnuBackColor.add(mniName[3]);
		mnuForeColor.add(mniName[4]);
		mnuForeColor.addSeparator();
		mnuForeColor.add(mniName[5]);
		for(i=6;i<15;i++){
			mnuPicture.add(mniName[i]);
		}
		for(i=15;i<23;i++){
			mnuFoodName.add(mniName[i]);
		}
		mnbBase.add(mnuSystem);
		mnbBase.add(mnuSetting);
		//����"����"���������
		pnlMsgbox1.add(lblMsgbox);
		pnlMsgbox2.add(btnMsgbox);
		
		//���������Ӧ�����
		pnlName[0].add(lblTitlePicture);
		pnlName[0].add(lblTime,BorderLayout.NORTH);
		//�ͻ���Ϣ����ʽ����
		for(i=1;i<5;i++){
			pnlName[i].setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
		}
		pnlName[1].add(lblName);
		pnlName[1].add(txtName);
		pnlName[2].add(lblAddress);
		pnlName[2].add(scoPane);
		pnlName[3].add(lblTel);
		pnlName[3].add(txtTel);
		pnlName[4].add(lblEmail);
		pnlName[4].add(txtEmail);
		//�۸���Ϣ���ʹ����������񲼾�
		pnlName[5].setLayout(new GridLayout(2,2));
		pnlName[5].add(lblMoney);
		pnlName[5].add(txtMoney);
		pnlName[5].add(lblDate);
		pnlName[5].add(cmbDate);
		pnlName[6].add(rdbPizza);
		pnlName[6].add(rdbBurger);
		//ʳ�︴ѡ�������񲼾֣���������ʳ�����ͷ���һ�������
		pnlName[7].setLayout(new GridLayout(2,2));
		for(i=0;i<4;i++){
			pnlName[7].add(cebFood[i]);
		}
		pnlName[8].setLayout(new GridLayout(2,2));
		for(i=4;i<8;i++){
			pnlName[8].add(cebFood[i]);
		}
		pnlName[9].add(pnlName[7]);
			
		pnlName[10].setLayout(new GridLayout(2,1));
		
		pnlName[10].add(pnlName[6]);
		pnlName[10].add(pnlName[9]);
		pnlName[11].add(lblFoodPicture);
		//����ѡ�����ӵ���¼�
		for(i=0;i<8;i++){
			cebFood[i].addItemListener(new AddPrice());
		}
		//����ť���ӵ���¼�
		btnOK.addActionListener(new ESC());
		btnExit.addActionListener(new ESC());
		btnESC.addActionListener(new ESC());
		btnRefurbish.addActionListener(new Refurbish());
		btnChangeBackColor.addActionListener(new ColorChoose());
		btnChangeForeColor.addActionListener(new ColorChoose());
		//����ѡ��ť���ӵ���¼�
		rdbPizza.addActionListener(new SelectFood());
		rdbBurger.addActionListener(new SelectFood());
		lblTitlePicture.addMouseListener(new MouseMove());
		//��������������
		pnlName[12].setLayout(new FlowLayout(FlowLayout.LEFT,2,2));	
		pnlName[12].add(pnlName[1]);
		pnlName[12].add(pnlName[2]);
		pnlName[12].add(pnlName[3]);
		pnlName[12].add(pnlName[4]);
		pnlName[12].add(pnlName[10]);
		pnlName[12].add(pnlName[11]);
		pnlName[12].add(pnlName[5]);		
		
		pnlName[13].add(btnOK);
		pnlName[13].add(btnExit);
		
		
		setJMenuBar(mnbBase);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		barPanel=new JPanel();
		barPanel.setLayout(new BorderLayout());
		barPanel.add(bar,BorderLayout.NORTH);
		barPanel.add(pnlName[0],BorderLayout.SOUTH);
		m.add(barPanel,BorderLayout.NORTH);
		m.add(pnlName[12],BorderLayout.CENTER);
		m.add(pnlName[13],BorderLayout.SOUTH);
		new TimeMove();
		new PictureChange();
		new GetDate();
		StartSetting();
	}
	private void Clear(){
		//��մ������ı���͸�ѡ�������
		txtName.setText("");
		tatAddress.setText("");
		txtTel.setText("");
		txtEmail.setText("");
		cmbDate.setSelectedIndex(0);
		for(i=0;i<8;i++){
			cebFood[i].setSelected(false);
		}
		rdbPizza.setSelected(true);
		m.repaint();
	}
	private void AddPicture(){
		//����ͼƬ
		lblTitlePicture.setIcon(icoName[8]);
		lblFoodPicture.setIcon(icoName[0]);
	}
	private void ChangeMsgboxForeColor(){
		//������������������ɫ
		lblMsgbox.setForeground(colMsgboxForeColor);
		btnMsgbox.setForeground(colMsgboxForeColor);
	}
	
	private void ChangeForeColor(){
		//���ñ�ǩ��������ɫ
		lblName.setForeground(colForeColor); 
		lblAddress.setForeground(colForeColor);
		lblTel.setForeground(colForeColor);
		lblEmail.setForeground(colForeColor);
		lblMoney.setForeground(colForeColor);
		lblDate.setForeground(colForeColor);
		lblTime.setForeground(colForeColor);
		lblTitlePicture.setForeground(colForeColor);
		lblFoodPicture.setForeground(colForeColor);
		lblMessage.setForeground(colForeColor);
		//���ð�ť��������ɫ
		btnOK.setForeground(colForeColor);
		btnExit.setForeground(colForeColor);
		txtName.setForeground(colForeColor);
		tatAddress.setForeground(colForeColor);
		txtTel.setForeground(colForeColor);
		txtEmail.setForeground(colForeColor);
		txtMoney.setForeground(colForeColor);
		//���ø�ѡ���������ɫ
		cmbDate.setForeground(colForeColor);
		for(i=0;i<8;i++){
			cebFood[i].setForeground(colForeColor);
		}
		//���õ�ѡ��ť��������ɫ
		rdbPizza.setForeground(colForeColor);
		rdbBurger.setForeground(colForeColor);
		//���ò˵���������ɫ
		mnbBase.setForeground(colForeColor);
		mnuSystem.setForeground(colForeColor);
		mnuSetting.setForeground(colForeColor);
		mnuBackColor.setForeground(colForeColor);
		mnuForeColor.setForeground(colForeColor);
		mnuPicture.setForeground(colForeColor);
		mnuFoodName.setForeground(colForeColor);
		for(i=0;i<23;i++){
			mniName[i].setForeground(colForeColor);
		}
		m.setForeground(colForeColor);
	}
	private void ChangeMsgboxBackColor(){
		//�����������ӱ���ɫ
		pnlMsgbox1.setBackground(colMsgboxBackColor);
		pnlMsgbox2.setBackground(colMsgboxBackColor);
	}
	private void ChangeBackColor(){
		//���ø�ѡ��ı���ɫ
		for(i=0;i<8;i++){
			cebFood[i].setBackground(colBackColor);
		}
		lblFoodPicture.setBackground(colBackColor);
		lblTime.setBackground(colBackColor);
		//���õ�ѡ��ť�ı���ɫ
		rdbPizza.setBackground(colBackColor);
		rdbBurger.setBackground(colBackColor);
		//�������ı���ɫ
		for(i=0;i<14;i++){
			pnlName[i].setBackground(colBackColor);
		}
		barPanel.setBackground(colBackColor);
		bar.setBackground(colBackColor);
		//���ò˵��ı�����ɫ
		mnbBase.setBackground(colBackColor);
		mnuSystem.setBackground(colBackColor);
		mnuSetting.setBackground(colBackColor);
		mnuBackColor.setBackground(colBackColor);
		mnuForeColor.setBackground(colBackColor);
		mnuPicture.setBackground(colBackColor);
		mnuFoodName.setBackground(colBackColor);
		for(i=0;i<23;i++){
			mniName[i].setBackground(colBackColor);
		}
		m.setBackground(colBackColor);
	}
	
	//���������߳�
	private void StartSetting(){
		ChangeForeColor();
		ChangeBackColor();
		ChangeMsgboxBackColor();
		ChangeMsgboxForeColor();
		AddPicture();
	}
	private class GetDate extends Thread{
		//���߳�������ʱ��
		Thread t;
		SimpleDateFormat sdf;
		Date d;
		public GetDate(){
			t = new Thread(this);
			t.start();
		}
		
		public void run(){
			try{
				while(intTime==0){
					t.sleep(1000);
					sdf = new SimpleDateFormat("yyyy'��' MMM dd'��',  EEE, HH:mm:ss ");
					d = new Date();
					lblTime.setText(sdf.format(d));
				}
			}
			catch(Exception e){
				System.out.println("�̱߳��жϣ�����");
			}
		}
	}
	class Msgbox extends JFrame{
	//����"����"����
		Container c;
		String strTitle;
		public Msgbox(String Title,ImageIcon ico,String Content,int x,int y,int nx ,int ny){
			super(Title);
			strTitle=new String(Title);
			this.setBounds(x,y,nx,ny);
			Font f=new Font("����",Font.BOLD,16);
			c=getContentPane();
			
			lblMsgbox.setFont(f);
			btnMsgbox.setIcon(ico);
			lblMsgbox.setText(Content);
			btnMsgbox.addMouseListener(new WindowClose());
			c.setLayout(new BorderLayout());
			c.add(pnlMsgbox1,BorderLayout.NORTH);
			c.add(pnlMsgbox2,BorderLayout.SOUTH);
			c.setBackground(colMsgboxBackColor);
			c.validate();
			c.repaint();
			pack();
			setResizable(false);
			setVisible(true);	
		}
		private class WindowClose extends MouseAdapter{
			//���ô���Ĺر��¼�
			public void mouseClicked(MouseEvent e){
				if (strTitle.equals("лл����"))
					Clear();
					dispose();
			}
		}
	}
	private class ButtonClick extends MouseAdapter{
		//����ı���Ϊ�գ��򵯳�"����"�Ĵ���
		public void mouseClicked(MouseEvent e){
				if (e.getSource().equals(btnOK)){
				if(txtName.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿�����",400,400,200,120);
				else if (tatAddress.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿͵�ַ",400,400,200,120);
				else if (txtTel.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿͵绰",400,400,200,120);
				else if (txtEmail.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿͵�������",400,400,200,120);
				else if (txtEmail.getText().indexOf('@')==-1||txtEmail.getText().indexOf('.')==-1||txtEmail.getText().indexOf('@')==0||txtEmail.getText().indexOf('.')==0||txtEmail.getText().indexOf('@')==txtEmail.getText().length()-1||txtEmail.getText().indexOf('.')==txtEmail.getText().length()-1)
					new Msgbox("����",icoName[13],"�˿͵ĵ�������Ƿ�",400,400,200,120);
				else if (txtMoney.getText().equals("$0"))	
					new Msgbox("����",icoName[14],"����,����û��ѡ��ʳ�� ",400,400,200,120);
				else
					new Msgbox("лл����",icoName[15],"Thanks " +txtName.getText()+", for buying " + rdbBurger.getText() + " of the cost " + txtMoney.getText()+", "+rdbBurger.getText() + "will be delivered "+cmbDate.getSelectedItem(),200,320,770,120);	
			}
			else
				System.exit(0);
	}
}
	private class SelectFood implements ActionListener{
	//���õ�ѡ��ť�ĵ���¼�
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==rdbPizza){
				pnlName[9].remove(pnlName[8]);
				pnlName[9].add(pnlName[7]);
				m.validate();
				m.repaint();	
			}
			else{
				pnlName[9].remove(pnlName[7]);
				pnlName[9].add(pnlName[8]);
				m.validate();
				m.repaint();
			}						
		}
	}
	private class AddPrice implements ItemListener{
	//���ø�ѡ��ť�ĵ���¼�
		public void itemStateChanged(ItemEvent e){
			String s=txtMoney.getText();
			lblFoodPicture.removeAll();
				if(e.getSource()==cebFood[0]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+10)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-10)));
						lblFoodPicture.setIcon(icoName[0]);
				}
				else if(e.getSource()==cebFood[1]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+15)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-15)));
						lblFoodPicture.setIcon(icoName[1]);
				}
				else if(e.getSource()==cebFood[2]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+20)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-20)));
						lblFoodPicture.setIcon(icoName[2]);
				}
				else if(e.getSource()==cebFood[3]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+25)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-25)));
						lblFoodPicture.setIcon(icoName[3]);
				}	
				else if(e.getSource()==cebFood[4]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+10)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-10)));
						lblFoodPicture.setIcon(icoName[4]);
				}	
				else if(e.getSource()==cebFood[5]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+15)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-15)));
						lblFoodPicture.setIcon(icoName[5]);
				}
				else if(e.getSource()==cebFood[6]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+20)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-20)));
						lblFoodPicture.setIcon(icoName[6]);
				}	
				else if(e.getSource()==cebFood[7]){
					if(e.getStateChange()==1)
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))+25)));
					else
						txtMoney.setText("$"+ (String.valueOf((Integer.parseInt(s.substring(1,s.length())))-25)));
						lblFoodPicture.setIcon(icoName[7]);
				}
				m.validate();
				m.repaint();			
			}		
	}
	private class Refurbish implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			Clear();
		}
	}
	
	private class ESC implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if (e.getSource().equals(btnOK)){
				if(txtName.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿�����",400,400,200,120);
				else if (tatAddress.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿͵�ַ",400,400,200,120);
				else if (txtTel.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿͵绰",400,400,200,120);
				else if (txtEmail.getText().length()==0)
					new Msgbox("����",icoName[13],"������˿͵�������",400,400,200,120);
				else if (txtEmail.getText().indexOf('@')==-1||txtEmail.getText().indexOf('.')==-1||txtEmail.getText().indexOf('@')==0||txtEmail.getText().indexOf('.')==0||txtEmail.getText().indexOf('@')==txtEmail.getText().length()-1||txtEmail.getText().indexOf('.')==txtEmail.getText().length()-1)
					new Msgbox("����",icoName[13],"�˿͵ĵ�������Ƿ�",400,400,200,120);
				else if (txtMoney.getText().equals("$0"))	
					new Msgbox("����",icoName[14],"����,����û��ѡ��ʳ�� ",400,400,200,120);
				else
					new Msgbox("лл����",icoName[15],"Thanks " +txtName.getText()+", for buying " + rdbBurger.getText() + " of the cost " + txtMoney.getText()+", "+rdbBurger.getText() + "will be delivered "+cmbDate.getSelectedItem(),200,320,770,120);	
			}
			else if(e.getSource().equals(btnExit)||e.getSource().equals(btnESC)||e.getSource().equals(mniName[1])){
				int select=JOptionPane.showConfirmDialog(m,"�Ƿ�����˳�","��ʾ",JOptionPane.OK_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE);
				if (select==JOptionPane.OK_OPTION)
					System.exit(0);
				}
		}
	}
	private class ColorChoose implements ActionListener{
		public void actionPerformed(ActionEvent e){
			//����ɫ�Ի���ѡ����Ҫ����ɫ
			if(e.getSource()==mniName[2]||e.getSource()==btnChangeBackColor){
				colBackColor=JColorChooser.showDialog(m,"�����屳����ɫ",Color.red);
				if (colBackColor!=null)
					ChangeBackColor();
			}
			else if(e.getSource()==mniName[3]){
				colMsgboxBackColor=JColorChooser.showDialog(m,"�Ի��򱳾���ɫ",Color.red);
				if (colMsgboxBackColor!=null)
					ChangeMsgboxBackColor();
			}
			else if(e.getSource()==mniName[4]||e.getSource()==btnChangeForeColor){
				colForeColor=JColorChooser.showDialog(m,"������������ɫ",Color.red);
				if (colForeColor!=null)
					ChangeForeColor();
			}
			else if(e.getSource()==mniName[5]){
				colMsgboxForeColor=JColorChooser.showDialog(m,"�Ի���������ɫ",Color.red);
				if (colMsgboxForeColor!=null)
					ChangeMsgboxForeColor();
			}
		}
	}
	private class PictureChoose implements ActionListener{
		public void actionPerformed(ActionEvent e){	
			//���ļ��Ի���ѡ����Ҫ��ͼƬ
			try{
					int result=chooser.showOpenDialog(Mcdonald.this);
					if (result==JFileChooser.APPROVE_OPTION){
					String name=chooser.getSelectedFile().getPath();
					if (name.substring(name.length()-3).equals("gif")||name.substring(name.length()-3).equals("jpg")){
					
						if(e.getSource()==mniName[6])
							icoName[8]=new ImageIcon(name);
						for(i=0;i<8;i++){
							if(e.getSource()==mniName[i+7])
								icoName[i]=new ImageIcon(name);
						}
						AddPicture();
					}
					else{
						throw new HeadlessException();
					}
					
				}
			}
			catch(HeadlessException f){
				new Msgbox("����",icoName[14],"�Բ���,���ļ�������Ч���ļ�",400,400,200,120);
			}
		}
	}
	private class FoodChoose implements ActionListener{
		public void actionPerformed(ActionEvent e){
			String FoodName=InputPanel.showInputDialog("�������µ�ʳ������");
			if (FoodName!=null){
				if (FoodName.equals("")){
				JOptionPane.showConfirmDialog(m,"ʳ�����Ʋ���Ϊ��","����",JOptionPane.CLOSED_OPTION,JOptionPane.WARNING_MESSAGE);
				}
				else{
					for(i=15;i<23;i++){
					if (e.getSource().equals(mniName[i])){
						strNewFood[i-15]=FoodName;
						mniName[i].setText(FoodName);
						mniName[i-8].setText(FoodName); 
						cebFood[i-15].setText(FoodName);
						}
					}
				}
			}

		}
	}
	
	//��꾭���м�ͼƬ��ʾ��Ϣ
	private class MouseMove implements MouseListener{
		public void mouseEntered(MouseEvent e){
			if(h==0)
			lblMessage.setText("������");
			else if(h==1)
			lblMessage.setText("������������");
			else if(h==2)
			lblMessage.setText("���������������");
			else if(h==3) 
			lblMessage.setText("������������������!!");
			else if(h==4){
				lblMessage.setText("");
				lblMessage.setIcon(icoName[14]);
			}
			else if(h==5){
				h=0;
				lblMessage.setIcon(null);
			}
				h++;
		}
		public void mouseExited(MouseEvent e){
			lblMessage.setText("");
        }
        public void mousePressed(MouseEvent e){
        }
        public void mouseClicked(MouseEvent e){
        }
        public void mouseReleased(MouseEvent e){
        }
	}
	
	//���̸߳����м��ͼƬ
	private class PictureChange extends Thread {
		Thread r;
		public PictureChange(){
			r=new Thread(this);
			r.start();
		}
		public void run(){
			try{
					while (intTime==0){
					r.sleep(10000);
					if(p>7)
						p=0;
					lblTitlePicture.setIcon(icoName[p]);
					p++;
					}
				}
			catch(Exception e){
				System.out.println("�̱߳��жϣ�����");
			}
		}
	}
	
	//���̸߳����������Ͱ�ť����ɫ
	private class TimeMove extends Thread {
		Thread h;
		public TimeMove(){
			h=new Thread(this);
			h.start();
		}
		public void run(){
			try{
					while (intTime==0){
						h.sleep(200);
						if (a>255)
							a=0;
						if(b>255)
							b=0;
						if(c>255)
							c=0;
						btnOK.setBackground(new Color(a,b,c));
						btnExit.setBackground(new Color(a,b,c));
						btnRefurbish.setBackground(new Color(a,b,c));
						btnChangeBackColor.setBackground(new Color(a,b,c));
						btnChangeForeColor.setBackground(new Color(a,b,c));
						btnESC.setBackground(new Color(a,b,c));
						a+=5;
						b+=10;
						c+=15;
					}
				}
			catch(Exception e){
				System.out.println("�̱߳��жϣ�����");
			}
		}
	}
}


//���
public class Login {
		public static void main(String args[]){
			
			//�ӵ�¼���棬��¼��������͵��ϵͳ
			LoginDialog login=new LoginDialog("��¼");		
			login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			login.setBounds(300,300,200,120);
			login.setVisible(true);
			
			
			/*
			//ֱ�Ӳ鿴���ͽ���
			Mcdonald zg=new Mcdonald("���͵��ϵͳ");
			zg.setResizable(false);
			zg.setBounds(300,120,370,580);
			zg.setVisible(true);
			*/
	}
}

//�����¼��
class LoginDialog extends JFrame{
	private JButton okButton,cancelButton;
	private JTextField nameText;
	private JPasswordField passwordText;
	private JLabel nameLabel,passwordLabel;
	private Container c;
	public LoginDialog(String title){
		this.setTitle(title);
		c=getContentPane();
		JPanel aPanel=new JPanel();
		JPanel bPanel=new JPanel();
		JPanel cPanel=new JPanel();
		okButton=new JButton("OK");
		okButton.addActionListener(new McdonaldShow());
		cancelButton=new JButton("Cancel");
		cancelButton.addActionListener(new McdonaldShow());
		nameText=new JTextField(10);
		nameLabel=new JLabel("�û���");
		passwordLabel=new JLabel("�û�����");
		passwordText=new JPasswordField(10);
		aPanel.setLayout(new GridLayout(2,2));
		aPanel.add(nameLabel);
		aPanel.add(nameText);
		aPanel.add(passwordLabel);
		aPanel.add(passwordText);
		bPanel.add(okButton);
		bPanel.add(cancelButton);
		cPanel.setLayout(new BorderLayout());
		cPanel.add(aPanel,BorderLayout.NORTH);
		cPanel.add(bPanel,BorderLayout.SOUTH);
		setDefaultCloseOperation(JDialog.EXIT_ON_CLOSE);
		c.add(cPanel);	
	}
	
	private class McdonaldShow implements ActionListener{
		public void actionPerformed(ActionEvent e){
				if (e.getSource().equals(okButton)){
					if (nameText.getText().equals("zg") && (new String(passwordText.getPassword())).equals("111")){
						Mcdonald zg=new Mcdonald("���͵��ϵͳ");
						zg.setResizable(false);
						zg.setBounds(300,120,370,580);
						zg.setVisible(true);
						dispose();
						
					}
					else if(nameText.getText().equals("") || new String(passwordText.getPassword()).equals(""))
						JOptionPane.showConfirmDialog(c,"�û��������벻��Ϊ��","����",JOptionPane.CLOSED_OPTION,JOptionPane.WARNING_MESSAGE);
					else{
						JOptionPane.showConfirmDialog(c,"�û������������","����",JOptionPane.CLOSED_OPTION,JOptionPane.WARNING_MESSAGE);
						nameText.setText("");
						passwordText.setText("");
					}
				}
				else
					System.exit(0);
			}
	}
}





