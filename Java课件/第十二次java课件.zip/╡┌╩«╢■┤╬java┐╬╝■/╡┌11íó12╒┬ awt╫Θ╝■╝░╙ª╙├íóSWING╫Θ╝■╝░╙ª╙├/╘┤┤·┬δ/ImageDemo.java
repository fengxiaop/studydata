import java.awt.*;
import javax.swing.*;
public class ImageDemo extends JPanel{
	
	public void paint(Graphics g){
		Toolkit tl=Toolkit.getDefaultToolkit();
		Image im=tl.getImage("image\\01.jpg"); //����ͼƬ����
		g.drawImage(im,50,50,250,250,this);    //�ڵ�ǰ����в鿴ͼƬ
	}
	
	public static void main(String args[]){
		JFrame f1=new JFrame();
		f1.getContentPane().add(new ImageDemo());
		f1.setSize(600,400);
		f1.setVisible(true);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}