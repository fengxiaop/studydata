package drawing;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.*;

public class FrameDrawing extends JFrame
{
  JPanel contentPane;
  BorderLayout borderLayout1 = new BorderLayout();
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenuGraphic = new JMenu();
  JMenuItem jMenuItemLine = new JMenuItem();
  JMenuItem jMenuItemRect = new JMenuItem();
  JMenuItem jMenuItemOval = new JMenuItem();
  JMenu jMenuColor = new JMenu();
  JMenuItem jMenuItemRed = new JMenuItem();
  JMenuItem jMenuItemGreen = new JMenuItem();
  JMenuItem jMenuItemBlue = new JMenuItem();
  JMenuItem jMenuItemPink = new JMenuItem();
  JMenuItem jMenuItemBlack = new JMenuItem();
  JMenu jMenuClean = new JMenu();
  JMenuItem jMenuItemClean = new JMenuItem();

  Color thisColor; // ��ǰͼ����ɫ
  Graphics g;
  String graphicType; // ��¼��ǰѡ���ͼ��
  int xStart, yStart, xEnd, yEnd; // ��갴�����ͷ�ʱ������
  boolean drawing = false; // ��־�Ƿ��ڻ�ͼ״̬

  //Construct the frame
  public FrameDrawing()
  {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try
    {
      jbInit();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception
  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(FrameDrawing.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    contentPane.setBackground(Color.white);
    this.setSize(new Dimension(400, 300));
    this.setTitle("�򵥵Ļ�ͼ����");

    jMenuGraphic.setText("ѡ��ͼ��");
    jMenuItemLine.setText("ֱ��");
    jMenuItemLine.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemLine_actionPerformed(e);
      }
    });
    jMenuItemRect.setText("����");
    jMenuItemRect.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemRect_actionPerformed(e);
      }
    });
    jMenuItemOval.setText("��Բ");
    jMenuItemOval.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemOval_actionPerformed(e);
      }
    });

    jMenuColor.setText("ѡ����ɫ");
    jMenuItemBlack.setText("��ɫ");
    jMenuItemBlack.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemBlack_actionPerformed(e);
      }
    });
    jMenuItemRed.setText("��ɫ");
    jMenuItemRed.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemRed_actionPerformed(e);
      }
    });
    jMenuItemGreen.setText("��ɫ");
    jMenuItemGreen.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemGreen_actionPerformed(e);
      }
    });
    jMenuItemBlue.setText("��ɫ");
    jMenuItemBlue.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemBlue_actionPerformed(e);
      }
    });
    jMenuItemPink.setText("��ɫ");
    jMenuItemPink.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemPink_actionPerformed(e);
      }
    });

    jMenuClean.setText("���");
    jMenuItemClean.setText("���ͼ��");
    jMenuItemClean.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItemClean_actionPerformed(e);
      }
    });
    jMenuBar1.add(jMenuGraphic);
    jMenuBar1.add(jMenuColor);
    jMenuBar1.add(jMenuClean);
    jMenuGraphic.add(jMenuItemLine);
    jMenuGraphic.add(jMenuItemRect);
    jMenuGraphic.add(jMenuItemOval);
    jMenuColor.add(jMenuItemBlack);
    jMenuColor.add(jMenuItemRed);
    jMenuColor.add(jMenuItemGreen);
    jMenuColor.add(jMenuItemBlue);
    jMenuColor.add(jMenuItemPink);
    jMenuClean.add(jMenuItemClean);
    this.setJMenuBar(jMenuBar1);

    contentPane.addMouseListener(new java.awt.event.MouseAdapter()
    {
      public void mousePressed(MouseEvent e)
      {
        contentPane_mousePressed(e);
      }
      public void mouseReleased(MouseEvent e)
      {
        contentPane_mouseReleased(e);
      }
      public void mouseEntered(MouseEvent e)
      {
        contentPane_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e)
      {
        contentPane_mouseExited(e);
      }
    });
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e)
  {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING)
    {
      System.exit(0);
    }
  }
  // �˵���ѡ��ͼ�Ρ����¼�����
  void jMenuItemLine_actionPerformed(ActionEvent e)
  {
    drawing = true;
    graphicType = "Line"; // ѡ��ֱ��
  }

  void jMenuItemRect_actionPerformed(ActionEvent e)
  {
    drawing = true;
    graphicType = "Rect"; // ѡ�����
  }

  void jMenuItemOval_actionPerformed(ActionEvent e)
  {
    drawing = true;
    graphicType = "Oval"; // ѡ����Բ
  }

  // �˵���ѡ����ɫ�����¼�����
  void jMenuItemBlack_actionPerformed(ActionEvent e)
  {
    thisColor = Color.black; // ��ɫ
  }

  void jMenuItemRed_actionPerformed(ActionEvent e)
  {
    thisColor = Color.red; // ��ɫ
  }

  void jMenuItemGreen_actionPerformed(ActionEvent e)
  {
    thisColor = Color.green; // ��ɫ
  }

  void jMenuItemBlue_actionPerformed(ActionEvent e)
  {
    thisColor = Color.blue; // ��ɫ
  }

  void jMenuItemPink_actionPerformed(ActionEvent e)
  {
    thisColor = Color.pink; // ��ɫ
  }

  // ��������˵����¼�����
  void jMenuItemClean_actionPerformed(ActionEvent e)
  {
    contentPane.update(g); // ��������е�ͼ��
  }

  // ��������¼��ĺ���
  void contentPane_mousePressed(MouseEvent e) // ��갴��
  {
    xStart = e.getX();
    yStart = e.getY();
  }

  void contentPane_mouseReleased(MouseEvent e) // ����ͷ�
  {
    xEnd = e.getX();
    yEnd = e.getY();
    if(drawing)
      Drawing();
  }

  void contentPane_mouseEntered(MouseEvent e) // �����뻭ͼ����
  {
    if(drawing)
      setCursor(Cursor.CROSSHAIR_CURSOR);
  }

  void contentPane_mouseExited(MouseEvent e) // ����Ƴ���ͼ����
  {
    setCursor(Cursor.getDefaultCursor());
  }

  // ����Ļ�ͼ����
  void DrawLine(int x1, int y1, int x2, int y2) // ��ֱ��
  {
    g = contentPane.getGraphics();
    g.setColor(thisColor);
    g.drawLine(x1, y1, x2, y2);
  }

  void DrawRect(int x, int y, int width, int height) // ������
  {
    g = contentPane.getGraphics();
    g.setColor(thisColor);
    g.drawRect(x, y, width, height);
  }

  void DrawOval(int x, int y, int width, int height) // ����Բ
  {
    g = contentPane.getGraphics();
    g.setColor(thisColor);
    g.drawOval(x, y, width, height);
  }

  // ������Ӧ�Ļ�ͼ����
  void Drawing()
  {
    if(graphicType.equals("Line"))
    {
      DrawLine(xStart, yStart, xEnd, yEnd);
    }
    else if(graphicType.equals("Rect"))
    {
      DrawRect(xStart, yStart, Math.abs(xEnd - xStart), Math.abs(yEnd - yStart));
    }
    else if(graphicType.equals("Oval"))
    {
      DrawOval(xStart, yStart, Math.abs(xEnd - xStart), Math.abs(yEnd - yStart));
    }
  }

}