package zhwd;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Temperature extends JFrame{ // �����
	Controler demo;
	public Temperature() {
		super("�������¶�ת��Ϊ�����¶�");
		demo = new Controler();

		Container contentPane = getContentPane();
		contentPane.add(demo);
		this.setSize(300, 200);
		setVisible(true);
	}

	public static void main(String args[]) {
		new Temperature();
	}
}

class Controler extends JPanel implements ActionListener{ // �������пؼ�
	JTextField input;
	JLabel Centigrade;
	JLabel Fahrenheit;
	JButton convent;
	String s1;

	public Controler() {
		input = new JTextField();
		Centigrade = new JLabel("�����¶�");
		Fahrenheit = new JLabel("�����¶�");
		convent = new JButton("convent");
		s1 = input.getText();

		setLayout(new GridLayout(2, 2));
		add(input);
		add(Centigrade);
		add(convent);
		add(Fahrenheit);

		convent.addActionListener(this);
	}

	public void actionPerformed(ActionEvent ae) {
		try {
			if (Integer.parseInt(input.getText()) < -273.15) {
				throw new Abnormity();
			} else {
				Fahrenheit.setText(this.count(Integer.parseInt(input.getText())) + "�����¶�");
			}
		} catch (Abnormity e) {
			Fahrenheit.setText(e.getMessage());
		} catch (NumberFormatException nf) {
			Fahrenheit.setText("��淶�������");
		}
	}

	double count(double condition) {
		double result;
		result = condition * 1.8 + 32;
		return result;
	}
}

class Abnormity extends Exception{ // �쳣����
	public Abnormity() {
		super("��������¶�ֵ������");
	}
}