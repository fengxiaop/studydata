package csty;

import java.awt.*;
import java.util.Random;

class COval extends Panel implements Runnable{
	
	private static final Color[] cols={Color.black,Color.blue,Color.cyan,Color.darkGray,Color.red,Color.green};
	private static Random rn=new Random();//�õ������
	int del;
	
	public COval(int del){
		this.del=del;
		Thread th=new Thread(this);//�߳�����
		th.start();
	}
	public void paint(Graphics g){
		int w,h;
		w=this.getSize().width;
		h=this.getSize().height;
				
		g.setColor(cols[rn.nextInt(cols.length)]);//�õ������		
		g.fillOval(0,0,w,h);
	}	
	public void run(){
		try{
			while(true){
				Thread.sleep(del);
				repaint();
			}						
		}catch(Exception e){
			e.printStackTrace();
		}	
	}	
}
public class Test extends Frame{
	
	public Test(int size,int del){
		this.setLayout(new GridLayout(size,size));
		for(int i=0;i<size*size;i++)
			this.add(new COval(del));
		this.setSize(300,300);
		this.setVisible(true);
	}
	public static void main(String args[]){
		int size,del;
		
		try{
			size=Integer.parseInt(args[0]);
			if(size<2 || size>12)
				throw new Exception();
		}catch(Exception e){
			size=3;
		}
		try{
			del=Integer.parseInt(args[1]);
			if(del<50 || del>2000)
				throw new Exception();
		}catch(Exception e){
			del=100;
		}
		new Test(size,del);	
	}
}
