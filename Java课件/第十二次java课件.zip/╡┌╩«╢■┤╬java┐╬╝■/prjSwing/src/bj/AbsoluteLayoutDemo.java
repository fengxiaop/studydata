package bj;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AbsoluteLayoutDemo extends JFrame{

	public AbsoluteLayoutDemo(String s){
		super(s);
		
		JLabel jlblName=new JLabel("�û�����");
		jlblName.setBounds(20, 20, 60, 20);		//���Բ��������������ʼλ�úʹ�С
		
		JTextField jtfName=new JTextField(16);
		jtfName.setBounds(80, 20, 150, 20);
		
		JLabel jlblPass=new JLabel("��    �룺");
		jlblPass.setBounds(20, 45, 60, 20);
		
		JPasswordField jpfPass=new JPasswordField(16);
		jpfPass.setBounds(80, 45, 150, 20);
		
		JButton jbtnOk=new JButton("ȷ��");		
		JButton jbtnCannel=new JButton("ȡ��");
		jbtnOk.setBounds(70,75,60,20);
		jbtnCannel.setBounds(140,75,60,20);
		
		Container con=this.getContentPane();
		con.setLayout(null);						//ȡ���Զ�����		
		con.add(jlblName);
		con.add(jtfName);
		con.add(jlblPass);
		con.add(jpfPass);
		con.add(jbtnOk);
		con.add(jbtnCannel);
		
		this.setBounds(200, 200, 265, 150);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		AbsoluteLayoutDemo djf=new AbsoluteLayoutDemo("��½");
	}

}
