package ys;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


//���ڴ�����ʾ �����ڲ�����ɰ�ť����¼���ʾ
public class ByInterclass extends JFrame{
	
	public ByInterclass(){
		
		JButton jbtnOk=new JButton("ȷ��");
		JButton jbtnCancel=new JButton("ȡ��");
		JPanel jp=new JPanel();
		jp.add(jbtnOk);
		jp.add(jbtnCancel);
		
		Container con=this.getContentPane();
		con.add(jp);
		
		this.setBounds(400, 300, 300, 300);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		ByInterclass aey=new ByInterclass();

	}

}
