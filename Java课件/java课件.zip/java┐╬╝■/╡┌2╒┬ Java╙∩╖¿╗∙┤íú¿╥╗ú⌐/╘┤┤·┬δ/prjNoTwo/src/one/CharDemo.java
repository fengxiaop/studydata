package one;

/**
 * ���������char����
*/
public class CharDemo{
		
	public static void main(String args[]){
		char ch1='\u0041';   
		System.out.print(ch1+"\t");
		System.out.println('A');
	
		char ch2='\u0061';	 
		System.out.print(ch2+"\t");
		System.out.println('a');
		
	}
}
