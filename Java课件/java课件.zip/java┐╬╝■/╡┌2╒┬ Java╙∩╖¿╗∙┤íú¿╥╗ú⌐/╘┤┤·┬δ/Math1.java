public class Math1{
    public static void main(String args[]){
       System.out.println("PI="+Math.PI);
       System.out.println("abs(-6.5)="+Math.abs(-6.5));
       System.out.println("round(6.5)="+Math.round(6.5));
       System.out.println("Math.max(-2.5,-3)="+Math.max(-2.5,-3));
       System.out.println("random()="+Math.random());
    }	
    
}