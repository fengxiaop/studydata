package two;

import java.util.Scanner;

public class IfDemo {
	public static void main(String[ ] args){	
//		Scanner sin=new Scanner(System.in);
//		System.out.print("������һ������(0-100):");
//		int testscore=sin.nextInt();

		int testscore=88;
		String grade;
		if(testscore>100){
			grade="����ĳɼ�";
		}else if(testscore>=90){
			grade="grade is:A";
		}else if(testscore>=80){
			grade="grade is:B";
		}else if(testscore>=70){
			grade="grade is:C";
		}else if(testscore>=60){
			grade="grade is:D";
		}else if(testscore>=0){
			grade="grade is:F";
		}else{
			grade="����ĳɼ�";
		}
		System.out.println(grade);
	}
}