import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PaintFigure extends JFrame	implements ActionListener	//�����
{
	JButton btnTriangle;	//�����ΰ�ť
	JButton btnRectangle;	//���ΰ�ť
	JButton btnEllipse;		//��Բ��ť
	JPanel jMainPanel = new JPanel();	//��ť���
	JPanel buttons = new JPanel();		//��ͼ���
	int i = 0;
	
	public PaintFigure()
	{
		super("������״");
		
		btnTriangle = new JButton("������");
		btnRectangle = new JButton("����");
		btnEllipse = new JButton("��Բ��");
		btnTriangle.addActionListener(this);
		btnRectangle.addActionListener(this);
		btnEllipse.addActionListener(this);
		
		buttons.add(btnTriangle);
		buttons.add(btnRectangle);
		buttons.add(btnEllipse);
		
		jMainPanel.setLayout(new GridLayout(3,3));		//��ͼ������ò���
		
		this.getContentPane().add(buttons,BorderLayout.NORTH);
		this.getContentPane().add(jMainPanel,BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,400);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getActionCommand().equals("������"))
		{
			if(i<9)
			{
				jMainPanel.add(new Triangle());
				jMainPanel.repaint();
				jMainPanel.validate();
				i++;
			}
		}
		else if(ae.getActionCommand().equals("����"))
		{
			if(i<9)
			{
				jMainPanel.add(new Rectangles());
				jMainPanel.repaint();
				jMainPanel.validate();
				i++;
			}
		}
		else if(ae.getActionCommand().equals("��Բ��"))
		{
			if(i<9)
			{
				jMainPanel.add(new Ellipse());
				jMainPanel.repaint();
				jMainPanel.validate();
				i++;
			}
		}
	}
	
	public static void main(String args[])
	{
		new PaintFigure();
	}
}

class Triangle extends JPanel		//������������
{
	int height,width;	//���Ŀ����
	
	
	public void paintComponent(Graphics g)
	{
		height = this.getSize().height;
		width = this.getSize().width;
		Polygon p = new Polygon();
		g.setColor(Color.blue);
		p.addPoint(0,height);
		p.addPoint(width/2,0);
		p.addPoint(width,height);
		g.fillPolygon(p);
	}
}

class Rectangles extends JPanel		//���ƾ�����
{
	int height,width;		//���Ŀ����
	
	public void paintComponent(Graphics g)
	
	{
		
		height = this.getSize().height;
		width = this.getSize().width;

		g.setColor(Color.red);
		g.fillRect(0,0,width,height);
	}
}

class Ellipse extends JPanel	//������Բ��
{
	int height,width;	//���Ŀ����
	
	public void paintComponent(Graphics g)
	{
		height = this.getSize().height;
		width = this.getSize().width;
		g.setColor(Color.yellow);
		g.fillOval(0,0,width,height);
	}
}