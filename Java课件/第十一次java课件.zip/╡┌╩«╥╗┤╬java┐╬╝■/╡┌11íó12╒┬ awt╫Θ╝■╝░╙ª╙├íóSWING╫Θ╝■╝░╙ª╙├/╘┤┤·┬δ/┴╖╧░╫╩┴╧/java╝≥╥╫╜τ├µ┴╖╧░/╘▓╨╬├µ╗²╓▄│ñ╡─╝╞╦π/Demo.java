import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JApplet;

public class Demo extends JFrame
{
	
	JRadioButton bArea=new JRadioButton("���");
	JRadioButton bCycle=new JRadioButton("�ܳ�");
	ButtonGroup bg=new ButtonGroup();
	JLabel labR=new JLabel("�뾶",JLabel.CENTER);
	JTextField txt=new JTextField();
	JButton calute=new JButton("����");
	JLabel labResult=new JLabel("Բ������뾶");
	NorthPanel NPanel=new NorthPanel();
	CenterPanel CPanel=new CenterPanel();
	
	public Demo()
	{
		this.setTitle("����Բ����������ܳ�");
		this.setSize(300,200);
		Container con=this.getContentPane();
		con.add(NPanel,BorderLayout.NORTH);
		con.add(CPanel,BorderLayout.CENTER);
	}
	
	public static void main(String args[])
	{
		Demo frame=new Demo();
		frame.show(true);
	}
	
	private class NorthPanel extends JPanel
	{		
		public NorthPanel()
		{
		 	bg.add(bArea);
		 	bg.add(bCycle);
		 	this.add(bArea);
		 	this.add(bCycle);
		}
	}
	
	private class CenterPanel extends JPanel implements ActionListener
	{		
		public CenterPanel()
		{
			 setLayout(new GridLayout(2,2,1,1));
			 add(labR);
			 add(txt);
			 add(calute);
			 add(labResult);			 
			 calute.addActionListener(this);
		}		
		
		public void actionPerformed(ActionEvent e)
		{
			try
			{
				String str=txt.getText();
				final double PI=3.14D;
				double R=Double.parseDouble(str);
				
				if(bArea.isSelected())
					labResult.setText(PI*R*R+"");
				else if(bCycle.isSelected())
					labResult.setText(2*PI*R+"");
				
			}catch(NumberFormatException ex){
				labResult.setText("����������Ч�ַ������������룡");
				txt.setText("");
				txt.requestFocus();
			}
		}
	}
}