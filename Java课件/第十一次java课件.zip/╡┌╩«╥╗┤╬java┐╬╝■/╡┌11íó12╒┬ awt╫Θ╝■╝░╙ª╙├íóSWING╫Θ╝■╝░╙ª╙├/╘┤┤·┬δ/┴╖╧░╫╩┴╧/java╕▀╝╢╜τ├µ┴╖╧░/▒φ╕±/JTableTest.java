import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import javax.swing.DefaultCellEditor;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JFrame;

import java.awt.*;
import java.awt.event.*;

public class JTableTest extends JFrame 
{
	JTable table;
	JScrollPane scrollPane;
	MyTableModel model;

	public JTableTest() 
	{
		addWindowListener(new WindowAdapter ()
		{
			public void windowClosing (WindowEvent e)
			{
				System.exit(0);
			}
		});
		
		model=new MyTableModel();
		//���Զ����ģ��������һ���������
		table = new JTable(model);
		initColumnSize(table);
		JScrollPane scrollPane = new JScrollPane(table);
		this.getContentPane().add(scrollPane, BorderLayout.CENTER);
		TableColumn sexColumn=table.getColumn("�Ա�");
		JComboBox comboBox=new JComboBox();
		comboBox.addItem("��");
		comboBox.addItem("Ů");
		//�����Ա��е����Ϊ��Ͽ�
		sexColumn.setCellEditor(new DefaultCellEditor(comboBox));
	}
	
	void initColumnSize(JTable table)
	{
		TableColumn column;
		//�����еĿ���
		column = table.getColumnModel().getColumn(0);
		column.setPreferredWidth(70);	
		column = table.getColumnModel().getColumn(1);
		column.setPreferredWidth(50);		
		column = table.getColumnModel().getColumn(2);
		column.setPreferredWidth(50);
		column = table.getColumnModel().getColumn(3);
		column.setPreferredWidth(60);
		column = table.getColumnModel().getColumn(4);
		column.setPreferredWidth(150);			
	}
	
	public static void main(String[] args) 
	{
		JTableTest app = new JTableTest();
		app.setSize(500,160);
		app.show();
	}
	//�Զ������ģ��
    class MyTableModel extends AbstractTableModel 
    {
    	//����
        final String[] columnNames = {"����", "�Ա�","����","�ѻ�","�绰����"};
        //�����е�����                              
        final Object[][] data = 
        {
            {"����", "��", 
             new Integer(21), new Boolean(false),"0750552431"},
            
            {"����", "��", 
             new Integer(43), new Boolean(true),"02086225857"},
            
            {"����", "Ů",
             new Integer(18), new Boolean(false),"01078465783"},
            
            {"�Ŷ�", "��",
             new Integer(20), new Boolean(true),"13457389678"},
            
            {"����", "Ů",
             new Integer(25), new Boolean(false),"02085216745"},
             
            {"����", "��", 
             new Integer(27), new Boolean(false),"552431345"},
             
            {"����", "Ů", 
             new Integer(19), new Boolean(false),"13066211290"},
        };
        
		//�����е�����
        public int getColumnCount() 
        {
            return columnNames.length;
        }
        
        //�����е�����
        public int getRowCount() 
        {
            return data.length;
        }
		
		//��������
        public String getColumnName(int col) 
        {
            return columnNames[col];
        }
		
		//����ָ��λ�õ�ֵ
        public Object getValueAt(int row, int col) 
        {
            return data[row][col];
        }
		
		//������������
        public Class getColumnClass(int c) 
        {
            return getValueAt(0, c).getClass();
        }

		//�ж��Ƿ��ܹ��޸�
        public boolean isCellEditable(int row, int col) 
        {
            if (col < 1) 
            { 
                return false;
            } 
            else 
            {
                return true;
            }
        }
		
		//����ָ��λ�õ�ֵ
        public void setValueAt(Object value, int row, int col) 
        {
            if (data[0][col] instanceof Integer&& !(value instanceof Integer)) 
            {
                try 
                {
                    data[row][col] = new Integer(value.toString());
                    fireTableCellUpdated(row, col);
                } 
                catch (NumberFormatException e) 
                {
					System.out.println(e);
                }
            } 
            else 
            {
                data[row][col] = value;
                fireTableCellUpdated(row, col);
            }
        }
    }
}
