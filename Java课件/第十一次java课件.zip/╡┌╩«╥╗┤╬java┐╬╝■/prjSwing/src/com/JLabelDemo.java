package com;

import java.awt.*;
import javax.swing.*;
public class JLabelDemo extends JFrame{

    public JLabelDemo(){
    	super("JLabelDemo");
    	//����һ��ֻ�����ֵı�ǩ
    	JLabel jl=new JLabel("OK");
    	
    	//����������ͼƬ�ı�ǩ
//    	ImageIcon ii=new ImageIcon("./dd/03.gif");
//    	JLabel jl=new JLabel("OK",ii,JLabel.CENTER);
    	
    	this.getContentPane().add(jl);
    	this.setLocation(450,280);
    	this.setSize(300,400);
    	this.setVisible(true);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   	}
   	public static void main(String args[]){
   	  JLabelDemo jd=new JLabelDemo();
   	}
}
