package com;

import java.awt.*;
import javax.swing.*;

public class JTextFieldDemo extends JFrame{

    public JTextFieldDemo(){
    	super("JTextFieldDemo");
    	JLabel jl=new JLabel("�ı���");
    	JTextField jtf=new JTextField("���ǵ����ı�����",20);
    	
    	this.getContentPane().setLayout(new FlowLayout());
    	this.getContentPane().add(jl);
    	this.getContentPane().add(jtf);
    	this.setLocation(450,280);
    	this.setSize(300,400);
    	this.setVisible(true);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   	}
   	public static void main(String args[]){
   	  JTextFieldDemo jd=new JTextFieldDemo();
   	}
}
