package cn;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SimpleLogin extends JFrame implements ActionListener{
	private JButton btnOk,btnCancel;
	private JPanel jpbtn,jpMain;
	private JLabel lblName,lblPassword;
	private JTextField jtfName;
	private JPasswordField jtfpassword;

	public SimpleLogin(String s){
		super(s);

		jpbtn=new JPanel();
		btnOk=new JButton("ȷ��");
		btnCancel=new JButton("ȡ��");
		jpbtn.add(btnOk);
		jpbtn.add(btnCancel);

		jpMain=new JPanel();
		lblName=new JLabel("�û���:");
		lblPassword=new JLabel("��    ��:");
		jtfName=new JTextField(15);
		jtfpassword=new JPasswordField(15);

		jpMain.add(lblName);
		jpMain.add(jtfName);
		jpMain.add(lblPassword);
		jpMain.add(jtfpassword);

		btnOk.addActionListener(this);
		btnCancel.addActionListener(this);

		this.getContentPane().add(jpbtn,BorderLayout.SOUTH);
		this.getContentPane().add(jpMain,BorderLayout.CENTER);

	}

	public void actionPerformed(ActionEvent e){

		if(e.getSource()==btnOk){
			if(jtfName.getText().equals("aa") && new String(jtfpassword.getPassword()).equals("123")){

				this.dispose();
				JOptionPane.showMessageDialog(null,"��¼�ɹ���ллʹ��","��¼�ɹ�",JOptionPane.INFORMATION_MESSAGE);
			}else{
				JOptionPane.showMessageDialog(null,"��¼ʧ�ܣ�ллʹ��","��¼ʧ��",JOptionPane.INFORMATION_MESSAGE);
			}
		}

		if(e.getSource()==btnCancel){
			System.exit(0);

		}

	}

	public static void main(String[] args){
		SimpleLogin login=new SimpleLogin("��½");
		login.setLocation(300,300);
		login.setSize(250,150);
		login.setVisible(true);
		login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
