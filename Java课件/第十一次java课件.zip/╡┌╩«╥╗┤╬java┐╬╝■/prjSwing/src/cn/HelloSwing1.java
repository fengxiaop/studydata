package cn;

import javax.swing.*;   
import java.awt.*;    
 
public class HelloSwing1 extends JFrame{
 
 public HelloSwing1(String s){
 	super(s);
 	JLabel label = new JLabel("�ַ�");
 	
 	java.awt.Container con;
    con=this.getContentPane();   //�������getContentPane()�������������
    con.add(label);
    
    //Ҳ����ʡдΪ����ģʽ
    //this.getContentPane().add(label);
   this.setSize(300,200);
   this.setVisible(true);
   this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 }
 
 public static void main(String[] args) {
   HelloSwing1 frame = new HelloSwing1("HelloSwing");   
  
 }
} 