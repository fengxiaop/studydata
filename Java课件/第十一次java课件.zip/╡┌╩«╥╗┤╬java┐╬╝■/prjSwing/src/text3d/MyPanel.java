package text3d;

import java.awt.*;
import javax.swing.JPanel;

public class MyPanel extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();

  public MyPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
  }

  int ShiftNorth(int p, int distance) { //�Զ��巽��������ȷ��λ��
     return (p - distance);
   }

  int ShiftSouth(int p, int distance) {
     return (p + distance);
   }

  int ShiftEast(int p, int distance) {
     return (p + distance);
   }

  int ShiftWest(int p, int distance) {
     return (p - distance);
   }


  public void paintComponent(Graphics g){
    int x = 10;
    int y = 60;
    //����Ч��
    Color top_color = new Color(200, 200, 0);
    Color side_color = new Color(100, 100, 0);
    g.setFont(new Font("TimesRoman",Font.PLAIN,60));
    for (int i = 0; i < 5; i++) {
      g.setColor(top_color);
      g.drawString("3-Dimension", ShiftEast(x, i), ShiftNorth(ShiftSouth(y, i), 1));
      g.setColor(side_color);
      g.drawString("3-Dimension", ShiftWest(ShiftEast(x, i), 1), ShiftSouth(y, i));
    }
    g.setColor(Color.yellow);
    g.drawString("3-Dimension", ShiftEast(x, 5), ShiftSouth(y, 5));
    //�ƶ�Ч��
    g.translate(50,80);
    int font_size , w , speed = 3 , width = 200;
    for (int i = 0; i < 20; i++) {
         font_size = 50 + i;
         g.setFont(new Font("TimesRoman", Font.PLAIN, font_size));
         w = (g.getFontMetrics()).stringWidth("Motion");
         g.setColor(new Color(0, 65 + i * 10, 0));
         g.drawString("Motion", (width - w) / 2, ShiftSouth(y, speed * i));
     }
  }
}
