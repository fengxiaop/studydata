package bj;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CardLayoutDemo extends JFrame{
	JPanel pnlCommandArea=new JPanel();
	JPanel pnlDisPalyArea=new JPanel();
	CardLayout cardlayout1=new CardLayout();
	JButton btnFirst=new JButton("��һ��");
	JButton btnPrevious=new JButton("ǰһ��");
	JButton btnNext=new JButton("��һ��");
	JButton btnLast=new JButton("���һ��");
	
	public CardLayoutDemo(){
		this.setLayout(new BorderLayout());
		
		this.add(pnlCommandArea,BorderLayout.NORTH);
		this.add(pnlDisPalyArea,BorderLayout.CENTER);
		pnlDisPalyArea.setLayout(cardlayout1);
		
		//���ð�ť���pnlCommandArea�����Ӱ�ť
		pnlCommandArea.add(btnFirst);
		pnlCommandArea.add(btnPrevious);
		pnlCommandArea.add(btnNext);
		pnlCommandArea.add(btnLast);
		
		//������ʾ���pnlDisPalyArea�е��Ŀ������
		JPanel pnlFirst=new JPanel();		//�����һ�����
		pnlFirst.setBackground(Color.blue);	//������屳��ɫΪ��ɫ		
		JLabel jlblFirst=new JLabel("this is first Panel");//����һ����ǩ
		jlblFirst.setForeground(Color.white);//���ñ�ǩǰ��ɫ������ǩ���ֵ���ɫ��Ϊ��ɫ
		pnlFirst.add(jlblFirst);//����ǩ���ص����pnlFirst��
		pnlDisPalyArea.add("first",pnlFirst);//����õ������ص�����Ϊ��Ƭ���ֵ����pnlDisPalyArea��
		
		JPanel pnlSecond=new JPanel();
		pnlSecond.setBackground(Color.red);		
		JLabel jlblSecond=new JLabel("this is Second Panel");
		jlblSecond.setForeground(Color.white);
		pnlSecond.add(jlblSecond);
		pnlDisPalyArea.add("second",pnlSecond);
		
		JPanel pnlThird=new JPanel();
		pnlThird.setBackground(Color.black);
		JLabel jlblThird=new JLabel("this is third Panel");
		jlblThird.setForeground(Color.white);
		pnlThird.add(jlblThird);
		pnlDisPalyArea.add("third",pnlThird);
		
		JPanel pnlFourth=new JPanel();
		pnlFourth.setBackground(Color.pink);
		JLabel jlblFourth=new JLabel("this is fourth Panel");
		jlblFourth.setForeground(Color.white);
		pnlFourth.add(jlblFourth);
		pnlDisPalyArea.add("fourth",pnlFourth);
		
		//�԰�ť���Ӽ����¼�
		btnFirst.addActionListener(new ActionListener(){ //new ActionListener()���÷��ǡ������ࡱ���μ��̲�p62
			public void actionPerformed(ActionEvent e){
				processAction(e);
			}
		});
		btnPrevious.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				processAction(e);
			}
		});
		btnNext.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				processAction(e);
			}
		});
		btnLast.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				processAction(e);
			}
		});
		
	
	}
	
	public static void main(String args[]){
		CardLayoutDemo frmCardDemo=new CardLayoutDemo();
		frmCardDemo.pack();
		frmCardDemo.setLocation(450,280);
		frmCardDemo.setSize(400,400);
		frmCardDemo.setVisible(true);
		frmCardDemo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void processAction(ActionEvent e){
		JButton btnEvent=(JButton)e.getSource();
		if(btnEvent.equals(btnFirst))
			cardlayout1.first(pnlDisPalyArea);
		else if(btnEvent.equals(btnLast))
			cardlayout1.last(pnlDisPalyArea);
		else if(btnEvent.equals(btnPrevious))
			cardlayout1.previous(pnlDisPalyArea);
		else if(btnEvent.equals(btnNext))
			cardlayout1.next(pnlDisPalyArea);
	}
}
