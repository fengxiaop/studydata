package menu;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;


//�������˵�
public class MainGui {
	JFrame frame;
	JMenuBar menuBar1;
	JMenu menu1, menu2, menu3, menu4, menu5, menu6, menu7, menu8;
	JMenuItem mi_book_add, mi_book_update, mi_book_delete, mi_reader_add, mi_reader_update, mi_reader_delete;
	JMenuItem mi_borrow, mi_return, mi_query_book, mi_query_reader, mi_update_reader, mi_exit;

	public MainGui() {
		frame = new JFrame("Library Menage System");
		menuBar1 = new JMenuBar();

		menu5 = new JMenu("Basic Maintain");

		menu6 = new JMenu("Book Maintain");
		mi_book_add = new JMenuItem("Add..");
		mi_book_update = new JMenuItem("Modify..");
		mi_book_delete = new JMenuItem("Delete..");
		menu6.addSeparator();
		menu6.add(mi_book_add);
		menu6.add(mi_book_update);
		menu6.add(mi_book_delete);

		menu7 = new JMenu("Reader Maintain");
		mi_reader_add = new JMenuItem("Add New User..");
		mi_reader_update = new JMenuItem("Modify User info..");
		mi_reader_delete = new JMenuItem("Delete User..");
		menu7.add(mi_reader_add);
		menu7.add(mi_reader_update);
		menu7.add(mi_reader_delete);

		menu1 = new JMenu("Borrow Information Manage");
		mi_borrow = new JMenuItem("Borrow");
		mi_return = new JMenuItem("Return");
		menu1.add(mi_borrow);
		menu1.add(mi_return);

		menu2 = new JMenu("Query System");
		mi_query_book = new JMenuItem("Book Query");
		mi_query_reader = new JMenuItem("User Query");
		menu2.add(mi_query_book);
		menu2.add(mi_query_reader);

		menu3 = new JMenu("System Manage");
		mi_exit = new JMenuItem("Quit");
		menu3.add(mi_exit);

		menuBar1.add(menu5);
		menuBar1.add(menu6);
		menuBar1.add(menu7);
		menuBar1.add(menu1);
		menuBar1.add(menu2);
		menuBar1.add(menu3);
		frame.setJMenuBar(menuBar1);
		frame.setLayout(new BorderLayout());
		frame.setSize(640, 480);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		new MainGui();
	}
}
