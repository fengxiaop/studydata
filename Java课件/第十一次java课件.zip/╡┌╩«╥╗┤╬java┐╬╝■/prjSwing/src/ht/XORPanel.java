package ht;

import java.awt.*;
import javax.swing.*;

public class XORPanel extends JPanel {
	 public void paintComponent(Graphics g){
		  super.paintComponent(g);
		  g.setColor(Color.red);
		  g.fillRect(10,10,80,30);
		  g.setColor(Color.green);
		  g.fillRect(50,20,80,30);
		 // g.setXORMode(Color.blue);//����ΪXOR��ͼģʽ
		 // g.setPaintMode();	   //����Ϊ����ģʽ��Ĭ��Ϊ����ģʽ
		  g.fillOval(90,30,80,30);

	 }

	 public static void main(String args[]){
		 	JFrame f1=new JFrame();
		 	XORPanel xor=new XORPanel();
		 	f1.add(xor);
		 	f1.setSize(400,300);
		 	f1.setVisible(true);
		 	f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 }
}