package ht;

import java.awt.*;
import javax.swing.*;


class ColorsPanel extends JPanel {   
   public void paintComponent(Graphics g) {
     super.paintComponent(g);
     this.setBackground(Color.RED);	//���ñ���ɫ
     this.setForeground(Color.BLUE);//����ǰ��ɫ���京���൱���ǻ���ͼ�ε�Ĭ����ɫ
     g.drawString("World",75,125);
    
//     Font f=new Font("Georgia",Font.ITALIC,16);     
//     g.setFont(f);
//     g.setColor(Color.red);		//���õ�ǰ������ɫ
//     g.drawString("Hello",75,100);
//     g.setColor(new Color(0,128,128));     
//     g.drawString("World",75,125);
        
   }
} 

class ColorFrame extends JFrame{
	public ColorFrame(){
		ColorsPanel cp=new ColorsPanel();
		this.getContentPane().add(cp);
		
		this.setBounds(300,300,400,300);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

public class ColorDemo{
	public static void main(String[] args){
		ColorFrame cf=new ColorFrame();
	}
}