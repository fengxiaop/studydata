window.__baidu_dup_jobruner = {};
try {
    var storage = window.localStorage;
    if (storage && storage.removeItem) {
        var time = new Date().getTime();
        storage.setItem('___ds_storage__isblock', '0|' + time);
    }
}
catch (e) {
}