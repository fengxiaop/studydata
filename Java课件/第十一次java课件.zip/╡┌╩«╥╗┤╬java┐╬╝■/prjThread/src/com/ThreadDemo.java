package com;

public class ThreadDemo{
	public static void main(String args[]){
	    TempThread1 t1=new TempThread1(1);
		TempThread1 t2=new TempThread1(2);
	
	    
        Thread th1=new Thread(t1);	
		Thread th2=new Thread(t2);
		
		th1.start();
		th2.start();
	}
}

class TempThread1  implements Runnable{
	int j;
	public  TempThread1(int m){
		j=m;
	};
	public void run(){		
		for(int i=1;i<50;i++){
			System.out.print(j+"  ");
		}
	}
}