var PFAN = {

	BASEURL : 'http://www.programfan.com',

	//ҳ�����
	sharePage : function( obj , url , title , content ){
		var sUrl = encodeURIComponent( url );
		var sTitle = (title == '') ? '' : encodeURIComponent('#��̰�����# ' + title);
		var sContent = (content == '')? '' : encodeURIComponent(content);
		var str = '';
		//����΢��
		str += '<a href="http://v.t.sina.com.cn/share/share.php?ralateUid=1651613740&appkey=2318506280&title='+ sTitle +'&url='+ sUrl +'" title="����������΢��" target="_blank"><img src="'+this.BASEURL+'/image/share_sina.png" border="0" /></a> ';
		//kaixin
		str += '<a href="http://www.kaixin001.com/~repaste/repaste.php?rtitle='+ sTitle +'&rurl='+ sUrl +'&rcontent='+ sContent +'" title="������������" target="_blank"><img src="'+this.BASEURL+'/image/share_kaixin.png" border="0" /></a> ';
		//douban
		str += '<a href="http://www.douban.com/recommend/?url='+ sUrl + '&title='+ sTitle +'" title="����������" target="_blank"><img src="'+this.BASEURL+'/image/share_douban.png" border="0" /></a> ';
		//������
		str += '<a href="http://share.renren.com/share/buttonshare.do?title='+ sTitle +'&link='+ sUrl +'" title="������������" target="_blank"><img src="'+this.BASEURL+'/image/share_renren.png" border="0" /></a> ';
		//qq
		str += '<a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='+ sUrl +'" title="������QZONE" target="_blank"><img src="'+this.BASEURL+'/image/share_qzone.png" border="0" /></a> ';
		document.getElementById(obj).innerHTML = str;
	},

	//��֤�������� begin
	//��֤url��ַ
	checkURL :  function( url )
				{
					var strRegex = "^(https|http)?:\/\/.*$";
					var re = new RegExp(strRegex);
					return re.test( url );
				},
	//��֤����
	checkNum :	function( num )
				{

				},

	//��֤email
	checkEmail :function( str )
				{
					var regu = "^[a-z0-9_\-]+(\.[_a-z0-9\-]+)*@([_a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel)$";
					var re = new RegExp( regu );
					if( str.search( re ) == -1 )
					{
						return false;
					}
					else
					{
						return true;
					}
				},
	//��֤�������� end

	DOVE : "mmx"
};
