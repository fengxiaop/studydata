package com;

public class OnePackage {
	public int aOnePackage=0;
	protected int bOnePackage=0;
	int cOnePackage=0;
	private int dOnePackage=0;
}
