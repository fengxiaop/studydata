package two;

public class Apple extends Fruit{
	
	public Apple(){
		this("�ƽ�ƻ��");
	}	
	public Apple(String brand){
		this.brand=brand;
	}
	
	public void show() {
		System.out.println("Apple:"+brand);
		
	}

}
