package cn;

public interface InterB {
	void fun();
	
	default void foo(){	
		System.out.println("calling InterB foo()");
	}
}
