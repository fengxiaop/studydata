abstract class Book{
	int bookPage;
	float discount;
	double price;
	
	abstract void show();
	
	abstract double getPrice(int bookPage,float discount);
	
	public Book(int bookPage,float discount){
		this.bookPage=bookPage;
		this.discount=discount;
	}
	
	public void show_price(){
		System.out.println("this book's price is "+price);
		}
	}
	
class Science_book extends Book{
	public Science_book(int bookPage,float discount){
		super(bookPage,discount);
	}
	
	public void show(){	//����Ҫʵ�����еĳ��󷽷�	
		System.out.println("this book's kind is science");
	} 
	
	public double getPrice(int bookPage,float discount){
		return bookPage*0.1*discount;
	}
}

public class Booksell{
	public static void main(String args[])	{
		Science_book bb=new Science_book(530,0.7f);
		bb.price=(int)bb.getPrice(530,0.7f);
		bb.show();
		bb.show_price();	
	}
}