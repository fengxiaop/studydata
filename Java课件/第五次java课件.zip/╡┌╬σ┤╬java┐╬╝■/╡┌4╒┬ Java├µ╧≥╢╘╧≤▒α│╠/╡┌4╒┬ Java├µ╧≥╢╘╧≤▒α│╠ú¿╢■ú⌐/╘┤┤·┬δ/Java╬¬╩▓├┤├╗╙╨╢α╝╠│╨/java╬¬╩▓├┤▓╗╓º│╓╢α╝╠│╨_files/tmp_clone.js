﻿//克隆模板的配置信息

$_GLOBAL.cloneTemplateConfig = {
	"8_52": {
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/8/8_52/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ''
    },
    "9_4": {
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/9/9_4/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "16_10": {
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/16/16_10/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: '<a href="http://gongyi.sina.com.cn/z/siyuan/index.shtml" target="_blank" style="right: 0px; position: absolute; top: -116px;"><div style="width:100px;height:100px;">&nbsp;</div></a>'
    },
    "10_38":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_38/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: ""
    },
    "10_68":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_68/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: ""
    },
    "10_69":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_69/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: ""
    },
    "10_71":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_71/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: ""
    },
    "10_72":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_72/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000205",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_73":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_73/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000206",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_74":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_74/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000207",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_75":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_75/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000208",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_76":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_76/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000209",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_77":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_77/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000210",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_78":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_78/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000211",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_79":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_79/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000212",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_80":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_80/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000213",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_81":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_81/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000214",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_82":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_82/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000215",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_86":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_86/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000216",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_87":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_87/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000217",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_88":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_88/images/anniu.gif" />',
    template_clone_link: "",
    template_clone_other: "",
    count_id:"00000218",
    count_text:"<span style='right:0px;position:absolute;top:-28px;'>新浪网友已传递了<span style='color:#ff00ff'>#{template_pv}</span>次</span>"
    },
    "10_103":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_103/images/anniu.gif" onclick="v7sendLog(\'84_02_01\')" />',
    template_clone_link: '<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=204720,300798,306076&cid=0,0,0&sid=299931&advid=358&camid=37389&show=ignore&url=http://client.sina.com.cn/dilanshengxue2011/index.html" target="_blank">越自然 悦倾心有奖专题</a>',
    template_clone_other: ''
    },
    "10_104":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_104/images/btn_link.png" alt="" />',
    template_clone_link: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_104/images/btn_other.png" alt="" /></a>',
    template_clone_other: ''
    },
    "10_105":{
    template_clone_pic: '<img onclick="v7sendLog(\'88_02_01\')" src="http://simg.sinajs.cn/blog7newtpl/image/10/10_105/images/btn01.png" />',
    template_clone_link: '',
    template_clone_other: '<a onclick="v7sendLog(\'88_02_02\')" href="http://client.sina.com.cn/fenjiuwyw/" target="_blank">立即点击</a>'
    },
    "10_106":{
    template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_106/images/btn_link.png" alt="" />',
    template_clone_link: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_106/images/btn_other.png" alt="" /></a>',
    template_clone_other: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_106/images/btn_other.gif" /></a>'
    },
    "10_108":{
        template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_108/images/anniu.png" alt="" />',
        template_clone_link: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_108/images/adsarea.png" alt="" /></a>',
        template_clone_other: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_108/images/adsarea.gif" /></a>'
    },
    "10_110":{
        template_clone_pic: '<img src="http://simg.sinajs.cn/blog7style/images/common/sg_trans.gif" alt=""/>',
        template_clone_link: '',
        template_clone_other: '<a href="http://vw.faw-vw.com/index.php" target="_blank"> </a>'
    },
    "10_111":{
        template_clone_pic: '<img src="http://simg.sinajs.cn/blog7style/images/common/sg_trans.gif" alt=""/>',
        template_clone_link: '',
        template_clone_other: '<a href="http://vw.faw-vw.com/index.php" target="_blank"> </a>'
    },
    "10_112":{
        template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_112/images/anniu.png" alt="" />',
        template_clone_link: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_112/images/adsarea.png" alt="" /></a>',
        template_clone_other: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_112/images/adsarea.gif"/></a>'
    },
	"10_114":{
		template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_114/images/anniu.png" alt="" />',
        template_clone_link: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_114/images/adsarea.png" alt="" /></a>',
        template_clone_other: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_114/images/adsarea.gif"/></a>'
    },
    "10_115":{
		template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_115/images/anniu.png" alt="" />',
        template_clone_link: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_115/images/adsarea.png" alt="" /></a>',
        template_clone_other: '<a href="http://www.subaru-china.cn/" target="_blank"><img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_115/images/adsarea.gif"/></a>'
    },
    "11_3":{
    template_clone_pic: '<br style="display:none;"/>',
    template_clone_link: '<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=197210,245056,250080&cid=0,0,0&sid=240475&advid=5476&camid=35809&show=ignore&url=http://client.sina.com.cn/201004greatwall/" target="_blank"><div style="width:100%;height:100%;cursor:pointer;"></div></a>',
    template_clone_other: ''
    },
    "11_4":{
    template_clone_pic: '<br style="display:none;"/>',
    template_clone_link: '<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=197211,245057,250081&cid=0,0,0&sid=240476&advid=5476&camid=35809&show=ignore&url=http://client.sina.com.cn/201004greatwall/" target="_blank"><div style="width:100%;height:100%;cursor:pointer;"></div></a>',
    template_clone_other: ''
    },
    "11_5":{
    template_clone_pic: '<br style="display:none;"/>',
    template_clone_link: '<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=197209,245055,250079&cid=0,0,0&sid=240474&advid=5476&camid=35809&show=ignore&url=http://client.sina.com.cn/201004greatwall/" target="_blank"><div style="width:100%;height:100%;cursor:pointer;"></div></a>',
    template_clone_other: ''
    },
    "11_11":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_11/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_12":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_12/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_13":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_13/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_14":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_14/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_15":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_15/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_16":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_16/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_17":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_17/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_18":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_18/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_19":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_19/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_20":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_20/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_21":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_21/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_22":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_22/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_23":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_23/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_24":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_24/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_25":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_25/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_26":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_26/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_27":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_27/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_28":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_28/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_29":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_29/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_30":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_30/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_31":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_31/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_32":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_32/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_33":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_33/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_34":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_34/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_35":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_35/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_36":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_36/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_37":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_37/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_38":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_38/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_39":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_39/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_40":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_40/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_41":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_41/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_42":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_42/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_43":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_43/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    },
    "11_44":{
    template_clone_pic: "<img src='http://simg.sinajs.cn/blog7newtpl/image/11/11_44/images/anniu.gif' />",
    template_clone_link: "",
    template_clone_other: ""
    }
  };

  $_GLOBAL.famous_conf={
    "10_58":{
      template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_58/images/anniu.gif" />',
      template_clone_link: "",
      template_clone_other: ""
    },
    "10_56":{
      template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_56/images/anniu.gif" />',
      template_clone_link: "",
      template_clone_other: ""
    },
    "10_67":{
      template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_67/images/anniu.gif" />',
      template_clone_link: "",
      template_clone_other: ""
    }
  };

  $_GLOBAL.GUANWANG={
    "10_26":{
      template_clone_pic: '<img src="http://simg.sinajs.cn/blog7newtpl/image/10/10_26/images/anniu.jpg" />',
      template_clone_link: "http://kobe.sina.com.cn/",
      template_clone_other: ""
    }
  };