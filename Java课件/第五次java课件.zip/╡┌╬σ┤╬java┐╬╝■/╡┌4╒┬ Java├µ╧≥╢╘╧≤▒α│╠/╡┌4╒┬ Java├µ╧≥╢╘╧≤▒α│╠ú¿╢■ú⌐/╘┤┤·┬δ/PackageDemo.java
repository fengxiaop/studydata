package mypackage;

class Calculate{
	public double area(int a,int b){
		return a*b;
	}
}

public class PackageDemo{
	public static void main(String args[])	{
		Calculate aa=new Calculate();
		double s;
		s=aa.area(4,5);
		System.out.println("s="+s);
	}
}