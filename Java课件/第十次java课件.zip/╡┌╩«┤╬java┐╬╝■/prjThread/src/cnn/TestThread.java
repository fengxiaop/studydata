package cnn;
public class TestThread extends Thread {	
	String strV;
	int sleepTime;	
	public TestThread(String strV,int sleepTime) {
		this.strV=strV;
		this.sleepTime=sleepTime;
	}	
	public void run() {
		try {
			int i;
			for(i=1;i<=20;i++) {
				System.out.print(strV);				
				Thread.sleep(sleepTime);
				if(i%10==0)
					System.out.println();
			}
		}catch(InterruptedException e) {			
		}		
	}
	public static void main(String[] args) {
		TestThread tt1=new TestThread("A ",50);
		tt1.start();		
		TestThread tt2=new TestThread("B ",300);
		tt2.start();

	}

}
