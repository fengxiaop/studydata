package com;

public interface InterA{
	default void foo(){	//�ȼ��� default public void foo()
		System.out.println("calling InterA foo()");
	}
}
