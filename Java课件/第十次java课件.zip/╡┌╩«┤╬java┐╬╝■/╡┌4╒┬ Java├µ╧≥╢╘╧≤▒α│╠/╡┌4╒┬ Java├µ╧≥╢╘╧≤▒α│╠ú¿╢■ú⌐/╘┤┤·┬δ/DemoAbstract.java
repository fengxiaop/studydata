 abstract class Book{
	protected String name;

	public Book(){
		name="English";
	}

	public Book(String name){
		this.name=name;
	}

	public  abstract String getBookName();
}

 //abstract class Science extends Book{ }  //����������������̳г�����

 public class DemoAbstract extends Book{
	DemoAbstract(String name){
		super(name);
	}
	public String getBookName(){
		return name;
	}
	public static void main(String args[]){
		//Book bb1=new Book("Java");		//�����಻��ʵ����
		DemoAbstract bb2=new DemoAbstract("Java");
		DemoAbstract bb3=new DemoAbstract("book");
		System.out.println("bb2.getBookName(): "+bb2.getBookName());
		System.out.println("bb3.getBookName(): "+bb3.getBookName());
	}
}