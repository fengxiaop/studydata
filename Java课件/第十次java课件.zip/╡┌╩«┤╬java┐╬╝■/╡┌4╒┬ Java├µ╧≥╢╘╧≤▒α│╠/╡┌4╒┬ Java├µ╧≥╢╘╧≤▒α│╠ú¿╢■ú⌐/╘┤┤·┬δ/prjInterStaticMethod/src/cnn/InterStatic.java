package cnn;

public interface InterStatic {
	static void show(){
		System.out.println("InterStatic static show()");
	}
}
