package bag;
public class X1{
	int x,y;
	
	public X1(int i,int j){
		this.x=i;
		this.y=j;
		System.out.println("x="+x+" "+"y="+y);
	}
	
	public void show(){
		System.out.println("this class is a X1");
	}
}