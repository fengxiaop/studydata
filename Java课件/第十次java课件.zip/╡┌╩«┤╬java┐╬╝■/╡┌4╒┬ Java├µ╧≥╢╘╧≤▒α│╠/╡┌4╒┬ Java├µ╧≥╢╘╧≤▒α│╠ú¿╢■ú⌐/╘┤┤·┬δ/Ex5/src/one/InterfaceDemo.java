package one;

public class InterfaceDemo {

	public static void main(String[] args) {
		AlarmGuardDoor agd=new AlarmGuardDoor();
		agd.open();
		agd.alarm();
		agd.guard();
		agd.close();

	}

}
