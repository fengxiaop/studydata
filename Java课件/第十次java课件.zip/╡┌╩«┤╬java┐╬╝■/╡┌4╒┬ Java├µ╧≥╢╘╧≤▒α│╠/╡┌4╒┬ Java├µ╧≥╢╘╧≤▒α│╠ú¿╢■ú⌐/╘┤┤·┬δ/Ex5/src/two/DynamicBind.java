package two;

public class DynamicBind {

	public static void main(String[] args) {
		Fruit f=new Apple("�츻ʿƻ��");
		f.show();
		
		f=new Pear("����");
		f.show();
		
		f=new Banane("���˽�");
		f.show();

	}

}
