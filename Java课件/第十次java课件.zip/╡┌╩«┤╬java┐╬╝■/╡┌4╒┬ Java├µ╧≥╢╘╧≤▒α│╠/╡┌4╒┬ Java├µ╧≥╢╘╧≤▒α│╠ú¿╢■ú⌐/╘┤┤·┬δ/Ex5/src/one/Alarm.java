package one;

public interface Alarm {
	void alarm();
}
