package cn;

public class CommClass {
	public int aCommClass=0;
	protected int bCommClass=0;
	int cCommClass=0;
	private int dCommClass=0;
}
