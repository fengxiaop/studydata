class SupDemo{	
	int x,y;
	SupDemo(){
		System.out.println("SupDemo()");
	} 
	 
	SupDemo(int x,int y){
		this.x=x;
		this.y=y;
		System.out.println("SupDemo(int x,int y)");
	}
	
}

 class SonDemo extends SupDemo{
	int e;
	SonDemo(){
	//	super();  //Ĭ�ϼ̳��˸��಻�������Ĺ��캯��
		System.out.println("SonDemo()");
	}  
	
	SonDemo(int x,int y,int e){
		//super(x,y); //û��ָ������super(x,y);����Ĭ�ϵ��õ���super();
		this.e=e;
		System.out.println("SonDemo(int x,int y,int e)");
	} 

}

public class ConstructorExtends{
	public static void main(String args[]){
		SonDemo dd1=new SonDemo();
	
		System.out.println("\n");
	
		SonDemo dd2=new SonDemo(3,4,5);
	}
}