package cn;

public class CatchMore{
	public static void main(String args[]){
		try {
			String num=args[0];
			int numValue=Integer.parseInt(num);

			System.out.println("ƽ��Ϊ "+numValue*numValue);

	    }catch(ArrayIndexOutOfBoundsException ne){
			System.out.println("δ�ṩ�κβ�����");
		}catch(NumberFormatException nb){
			System.out.println("�������֣�");
		}
	}
}
