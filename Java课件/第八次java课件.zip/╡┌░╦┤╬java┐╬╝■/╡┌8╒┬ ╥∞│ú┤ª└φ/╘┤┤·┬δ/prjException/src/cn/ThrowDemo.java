package cn;

import java.io.IOException;

public class ThrowDemo{
	public static int Sum(int n) {
		if(n<0)
			throw new IllegalArgumentException("n��Ҫ�����0"); //�ֶ��׳��쳣			
		int s=0;
		for(int i=0;i<n;i++)
			s=s+i;
		return s;
	}
	
	public static void main(String args[]){
		try{
			int n=Integer.parseInt(args[0]);
			System.out.println(Sum(n));
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("command method "+"java Exception3 <number>");
		}catch(NumberFormatException e){
			System.out.println("the parameters <number> should be Integer!");
		}catch(IllegalArgumentException e){
			System.out.println("error parameters: "+e.toString());
		}catch(Exception e){
			System.out.println(e+" end");
		}
		finally{
			System.out.println("program is over!");
		}		
	}
}
