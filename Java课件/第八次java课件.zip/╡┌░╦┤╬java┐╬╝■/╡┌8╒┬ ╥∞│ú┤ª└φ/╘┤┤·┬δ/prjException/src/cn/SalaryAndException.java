package cn;

import javax.swing.JOptionPane;

class MathException extends Exception{
	MathException(){
		System.out.println("Enter the correct!!!");
	}
}

public class SalaryAndException{
	public static String name;
	public static int pay;

	public static void inputdata() throws MathException{
		try{
			String str;

			name=JOptionPane.showInputDialog("input the name: ");
			if(name.equals("") || name==null)
				throw new Exception("Name cannot be null");

			str=JOptionPane.showInputDialog("input the salary:");
			pay=Integer.parseInt(str);
			if (pay<0)
				throw new MathException();
		}catch(Exception e){
			System.out.println(e);		//	System.out.println("Exception"+e.toString);
			System.exit(0);
		}
	}

	public static void main(String args[]){
		try{
			for(int i=1;i<5;i++){
				inputdata();
				System.out.println(name+"'s Annual salary:"+pay*12);//������н
			}
		}catch(MathException pt){
			System.out.println("chu cuo"+pt.toString());
			System.exit(0);
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
}
