package com.jdk9.human;

public class Human {
    private String name;
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
    public static void main(String[] args) {
        Module m = Human.class.getModule();
        System.out.println(m);
    }
 
}
