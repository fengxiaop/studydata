package prjinterface;

public class TestPriInterface implements PriInterface {

	public static void main(String[] args) {
		TestPriInterface test = new TestPriInterface();
		test.testInterfacePrivate();
		
	
		
	}

}
