package two;

public abstract class Fruit {
	
	protected String brand;
	
	public abstract void show();
}
