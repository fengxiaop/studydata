package one;

public abstract class Door {
	abstract void open();
	abstract void close();
}
