package one;

public interface Guard {
	void guard();
}
