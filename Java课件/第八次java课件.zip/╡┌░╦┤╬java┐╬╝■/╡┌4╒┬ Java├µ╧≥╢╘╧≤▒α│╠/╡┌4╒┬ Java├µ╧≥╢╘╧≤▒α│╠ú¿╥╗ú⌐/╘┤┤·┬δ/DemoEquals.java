public class DemoEquals{
	public static void main(String args[]){
		
		Object oa=new Object();
		Object ob=new Object();
		Integer intg=new Integer(10);
		Integer intg2=new Integer(10);
		
		System.out.println(oa.equals(ob));
		System.out.println(intg.equals(intg2));
	}
}