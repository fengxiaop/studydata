package com;

import java.io.*;

public class SystemInMore{
	public static void main(String[] args) throws IOException{
		char c;
		System.out.print("please input a string:");
		c=(char)System.in.read();
		System.out.println("the first char is :"+c);
		c=(char)System.in.read();
		System.out.println("the second char is :"+c);
		c=(char)System.in.read();
		System.out.println("the third char is :"+c);
		
	}
}