package entity;

public class Employee {
	private String no;
	private String name;
	private String sex;
	private double salary;
	
	public Employee(String no,String name,String sex,double salary){
		this.no=no;
		this.name=name;
		this.sex=sex;
		this.salary=salary;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
