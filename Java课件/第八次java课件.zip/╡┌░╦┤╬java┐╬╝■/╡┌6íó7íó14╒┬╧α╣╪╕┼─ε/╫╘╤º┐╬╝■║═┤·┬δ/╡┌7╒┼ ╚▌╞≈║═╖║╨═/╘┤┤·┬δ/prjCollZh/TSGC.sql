DROP DATABASE IF EXISTS `TSGC`;
CREATE DATABASE `TSGC` /*!40100 DEFAULT CHARACTER SET gbk */;
USE `TSGC`;

CREATE TABLE `employee` (
  `no` 		varchar(255) 	DEFAULT NULL,
  `name` 	varchar(255) 	DEFAULT NULL,
  `sex` 	varchar(255) 	DEFAULT NULL,
  `salary`	decimal(10,2)
) DEFAULT CHARSET=gbk;

insert into employee values('1001','����','��',3500);
insert into employee values('1002','����','��',8500);
insert into employee values('2001','����','Ů',4500);
