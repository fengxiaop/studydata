use master
go

IF EXISTS(select * from sysdatabases where name='TSGC')
	DROP DATABASE TSGC;
go
CREATE DATABASE TSGC;
go
USE TSGC;
go

CREATE TABLE employee (
  no 		varchar(255) 	DEFAULT NULL,
  name 		varchar(255) 	DEFAULT NULL,
  sex 		varchar(255) 	DEFAULT NULL,
  salary	decimal(10,2)
)
go 

insert into employee values('1001','����','��',3500);
go
insert into employee values('1002','����','��',8500);
go
insert into employee values('2001','����','Ů',4500);
go