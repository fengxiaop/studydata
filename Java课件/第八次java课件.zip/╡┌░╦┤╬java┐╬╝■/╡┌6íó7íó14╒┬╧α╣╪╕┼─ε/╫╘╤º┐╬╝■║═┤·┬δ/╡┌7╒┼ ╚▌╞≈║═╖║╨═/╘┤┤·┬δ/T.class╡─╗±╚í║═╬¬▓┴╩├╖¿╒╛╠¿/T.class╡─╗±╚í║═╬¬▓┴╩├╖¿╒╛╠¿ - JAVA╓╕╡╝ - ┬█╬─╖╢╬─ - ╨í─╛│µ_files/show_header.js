var cpro_id = 'u3818';
document.write('<scr'+'ipt type="text/javascript" src="http://cpro.baidu.com/cpro/ui/c.js"></scr'+'ipt>');

