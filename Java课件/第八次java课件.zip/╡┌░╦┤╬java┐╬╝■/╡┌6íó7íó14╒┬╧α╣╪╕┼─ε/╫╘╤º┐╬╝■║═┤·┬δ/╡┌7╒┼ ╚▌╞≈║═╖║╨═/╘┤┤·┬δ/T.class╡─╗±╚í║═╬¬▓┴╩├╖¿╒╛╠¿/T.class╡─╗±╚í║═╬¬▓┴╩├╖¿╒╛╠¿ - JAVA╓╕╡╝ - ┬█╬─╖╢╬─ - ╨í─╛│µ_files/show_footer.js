
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fba3c8a9f8df0a6a83fcf4ad12ea9581e' type='text/javascript'%3E%3C/script%3E"));

