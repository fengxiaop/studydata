package two;

public class ImpLambda2 implements InterLambda2{
	public void test(int value){
		System.out.println("ImpLambda ���淽ʽʵ��"+value);
	}
}
