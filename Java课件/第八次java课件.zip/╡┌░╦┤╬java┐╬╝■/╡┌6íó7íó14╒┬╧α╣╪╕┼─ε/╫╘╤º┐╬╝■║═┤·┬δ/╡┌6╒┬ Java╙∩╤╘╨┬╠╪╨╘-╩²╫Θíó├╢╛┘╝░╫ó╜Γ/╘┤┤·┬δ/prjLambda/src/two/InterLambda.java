package two;

public interface InterLambda {		
	void test(int value);
}
