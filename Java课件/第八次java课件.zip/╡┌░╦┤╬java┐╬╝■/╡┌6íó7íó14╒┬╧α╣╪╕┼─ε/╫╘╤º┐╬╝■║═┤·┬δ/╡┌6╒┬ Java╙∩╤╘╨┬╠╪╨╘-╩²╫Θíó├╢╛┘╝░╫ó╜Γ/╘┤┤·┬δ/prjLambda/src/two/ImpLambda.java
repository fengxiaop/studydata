package two;

public class ImpLambda implements InterLambda{
	public void test(int value){
		System.out.println("ImpLambda ���淽ʽʵ��"+value);
	}
}
