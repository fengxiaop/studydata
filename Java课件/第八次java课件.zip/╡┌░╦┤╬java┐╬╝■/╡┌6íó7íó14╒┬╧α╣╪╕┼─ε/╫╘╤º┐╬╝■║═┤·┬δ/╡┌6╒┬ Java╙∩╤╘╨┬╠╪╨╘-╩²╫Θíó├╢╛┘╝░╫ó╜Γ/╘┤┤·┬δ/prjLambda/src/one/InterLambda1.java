package one;

public interface InterLambda1 {
	public void fun();
}
