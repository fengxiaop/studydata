package cn;

//��ʽһ(��һ��)
class OverFlowException extends Exception{ 
//��ʽ��(��һ��)
//class OverFlowException extends RuntimeException{
	OverFlowException(){
//	OverFlowException(String e){	
		System.out.println("there is OverFlow :OverFlowException");
	}
}

public class SelfExceptionTwo{
	public static int x=100000;
	//��ʽһ(�ڶ���)
	public static int multi() throws OverFlowException{
	//��ʽ��(�ڶ���)
//	public static int multi(){
		int aim;
		aim=x*x*x;
		if(aim>2.15E9||aim<0){
			throw new OverFlowException();
		//	throw new OverFlowException("hi");
			}
		else
			return x*x;
	}	

	public static void main(String args[]){
		int y;
		try{
			y=multi();
			System.out.println("y="+y);
		}catch(OverFlowException e)	{
			System.out.println(e.toString());
	//		System.out.println(e);
		}			
	}
}