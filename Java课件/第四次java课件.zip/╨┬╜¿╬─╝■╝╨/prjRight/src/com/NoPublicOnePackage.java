package com;

class NoPublicOnePackage {
	public int i=100;
}
