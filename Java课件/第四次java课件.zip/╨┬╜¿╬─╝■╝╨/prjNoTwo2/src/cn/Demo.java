package cn;

public class Demo {

	public static void main(String[] args) {
		int a[][]=new int[4][3];
		//a.length		4		12

	}

}
