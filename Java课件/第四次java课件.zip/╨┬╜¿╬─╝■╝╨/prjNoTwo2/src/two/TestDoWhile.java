package two;

public class TestDoWhile{
	public static void main(String args[]){
		int i=2;		//������
		double jc=1;	//�۳���
		do{
			jc=jc*i;
			i++;
		}while(i<=10);

		System.out.println("jc="+jc);
	}
}