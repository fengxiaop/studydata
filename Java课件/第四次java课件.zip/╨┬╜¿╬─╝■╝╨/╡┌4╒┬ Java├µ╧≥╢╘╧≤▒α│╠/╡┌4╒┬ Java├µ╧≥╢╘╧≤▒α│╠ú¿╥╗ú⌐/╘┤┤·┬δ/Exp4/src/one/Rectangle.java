package one;

public class Rectangle {
	private double width;
	private double length;

	public Rectangle(){
		this.width=5;
		this.length=6;
	}
	
	public Rectangle(double w,double l){
		this.width=w;
		this.length=l;
	}

	public double area(){		//�����		
		return this.width*this.length;
	}
	 
	public double perimeter(){	//���ܳ�
		return 2*(this.width+this.length);
	}
	
	public static void main(String[] args) {
		Rectangle r1=new Rectangle();
		System.out.println("r1���ܳ���"+r1.perimeter());
		System.out.println("r1�������"+r1.area());
		
		System.out.println();
		Rectangle r2=new Rectangle(10,20);
		System.out.println("r2���ܳ���"+r2.perimeter());
		System.out.println("r2�������"+r2.area());
	}
	
	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

}
