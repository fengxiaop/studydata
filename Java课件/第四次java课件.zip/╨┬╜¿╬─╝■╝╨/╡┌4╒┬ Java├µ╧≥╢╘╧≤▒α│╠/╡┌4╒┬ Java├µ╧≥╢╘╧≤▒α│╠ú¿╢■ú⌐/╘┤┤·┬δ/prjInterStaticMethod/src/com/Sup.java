package com;

public class Sup {
	
	public static void fun(){
		System.out.println("Sup fun()");
	}
}
