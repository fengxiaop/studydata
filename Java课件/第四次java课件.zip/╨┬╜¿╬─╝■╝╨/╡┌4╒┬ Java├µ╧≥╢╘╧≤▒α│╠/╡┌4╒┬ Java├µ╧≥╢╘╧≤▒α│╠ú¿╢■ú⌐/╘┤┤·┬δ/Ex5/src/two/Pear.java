package two;

public class Pear extends Fruit{
	public Pear(){
		this("ˮ����");
	}	
	public Pear(String brand){
		this.brand=brand;
	}
	
	public void show() {
		System.out.println("Pear:"+brand);
		
	}
}
