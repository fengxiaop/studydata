interface CAR{
    void start();
    void stop();
}

class SmallCar implements CAR{
    public void start(){
        System.out.println("smallcar start...");
    }

    public void stop(){
        System.out.println("smallcar stop!");
    }
}
class BigCar implements CAR{
    public void start(){
        System.out.println("bigcar start...");
    }

    public void stop(){
        System.out.println("bigcar  stop!");
    }
}

public class TestCar{
    public static void main(String[] args){
         //��ͨ�÷�
         System.out.println("==========��ͨ�÷�==================");
         SmallCar sc=new SmallCar();
         sc.start();
         sc.stop();

         BigCar  bc = new BigCar();
         bc.start();
         bc.stop();

         System.out.println("\n\n==========��̬��==================");
         //��̬���÷�
         CAR c=sc;
         c.start();
         c.stop();

         c=bc;
         c.start();
         c.stop();
    }
}