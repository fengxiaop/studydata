package cn;

public interface InterA {
	void fun();
	
	default void foo(){	//�ȼ���public default void foo()
		System.out.println("calling InterA foo()");
	}
}
