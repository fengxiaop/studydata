package cn;

public class Demo {
	
	int i=100;
	
	static int d=10000;

	public static void main(String[] args) {
		Demo demo=new Demo();
		int sum=demo.i+100;
		sum=sum+demo.d;
		
		Math.sqrt(9);
		
		System.out.println(Math.PI);
		
		System.out.println(Demo.d+10);

	}

}
