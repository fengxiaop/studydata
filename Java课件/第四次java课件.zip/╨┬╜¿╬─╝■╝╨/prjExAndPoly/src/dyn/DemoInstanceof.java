package dyn;

public class DemoInstanceof{
	public static void main(String args[]){
	    DemoInstanceof di=new DemoInstanceof();
	    System.out.println(di instanceof DemoInstanceof) ;
	    System.out.println(di instanceof Object) ;
	}
}