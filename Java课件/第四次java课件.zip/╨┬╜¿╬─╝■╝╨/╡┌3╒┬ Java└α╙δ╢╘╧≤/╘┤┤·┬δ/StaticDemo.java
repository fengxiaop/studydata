public class StaticDemo{

	static int i=1; //��̬����������ʵ�������ñ���

	public static void main(String args[]){

		System.out.println("before StaticDemo.i="+StaticDemo.i);
		StaticDemo.i=10;	//ͬһ��i
		System.out.println("after StaticDemo.i="+StaticDemo.i);

		System.out.println("\n");
		StaticDemo sd=new StaticDemo();
		sd.i=100;			//ͬһ��i
		System.out.println("after sd StaticDemo.i="+StaticDemo.i);
		System.out.println("after sd sd.i="+sd.i);

		System.out.println("\n");
		StaticDemo sd1=new StaticDemo();
		sd1.i=1000;			//ͬһ��i
		System.out.println("after sd1 StaticDemo.i="+StaticDemo.i);
		System.out.println("after sd1 sd.i="+sd.i);
		System.out.println("after sd1 sd1.i="+sd1.i);

	}
}