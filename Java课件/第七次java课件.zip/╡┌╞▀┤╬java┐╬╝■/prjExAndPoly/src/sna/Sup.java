package sna;

public class Sup {
	public void fun(){
		System.out.println("����Sup fun()");
	}
	
	public void show(int i){
		System.out.println("����Sup show(int i)");
	}
}
