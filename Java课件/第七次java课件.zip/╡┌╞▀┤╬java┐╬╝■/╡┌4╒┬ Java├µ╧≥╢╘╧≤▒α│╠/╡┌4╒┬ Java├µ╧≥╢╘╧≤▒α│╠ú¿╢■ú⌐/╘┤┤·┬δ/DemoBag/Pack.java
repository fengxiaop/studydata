import bag.X1;
import bag.X2;


class Pack{
	public static void main(String args[]){
		X1 aa=new X1(4,5);
		aa.show();
		X2 bb=new X2(10,20);
		bb.show();
	}
}