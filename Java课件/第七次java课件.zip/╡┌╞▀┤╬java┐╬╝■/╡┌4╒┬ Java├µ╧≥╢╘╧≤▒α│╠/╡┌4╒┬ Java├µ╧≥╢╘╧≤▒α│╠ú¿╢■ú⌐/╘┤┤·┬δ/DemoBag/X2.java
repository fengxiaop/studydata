package bag;
public class X2{
	int m,n;
	
	public X2(int i,int j){
		this.m=i;
		this.n=j;
		System.out.println("m="+m+" "+"n="+n);
	}
	
	public void show(){
		System.out.println("this class is a X2");
	}
}