package two;

public class Banane extends Fruit{
	
	public Banane(){
		this("ǧ�㽶");
	}	
	public Banane(String brand){
		this.brand=brand;
	}
	
	public void show() {
		System.out.println("Banane:"+brand);		
	}
}
