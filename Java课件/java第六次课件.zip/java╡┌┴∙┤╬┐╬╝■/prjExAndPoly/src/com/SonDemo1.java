package com;

class SupDemo1{
	int i;
	SupDemo1(){
		System.out.println("SupDemo()");
	}
	public void show() {
		System.out.println("super Demo2");
	}
}

public class SonDemo1 extends SupDemo1{
	int j;
	
	public void show() {
		System.out.println("sub Demo2");
	}
	public static void main(String[] args) {
		SonDemo1 sd1=new SonDemo1();
		sd1.i=1000;
	}

}
