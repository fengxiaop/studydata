//����Բ������Բ���
class Calculate{
	final double PI=3.14159;
	
	void area(double r){
		double x;
		x=PI*r*r;
		System.out.println("area="+x);
	}
	
	public static void main(String args[]){
		Calculate dd=new Calculate();
		dd.area(12.3);			//Instance.methodName()
	}
}