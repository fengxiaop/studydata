class Demo{
	public int a=10;
	protected int b=20;
	int c=20;
	private int d=40;
	
	void getNumber(){
		System.out.println("a="+a+"b="+b+"c="+c);
		System.out.println("d="+d);
	}
}

public class FieldDemo{
	public static void main(String args[]){
		Demo demo=new Demo();
		System.out.println("demo.a="+demo.a+"\tdemo.b="+demo.b+"\tdemo.c="+demo.c);
		//	System.out.println("demo.d="+demo.d);	//���д����޷�����˽�г�Աd
		
		System.out.println(Math.pow(2.1,3));
	}
}